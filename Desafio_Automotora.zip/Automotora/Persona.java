/**
 * 
 */
package Automotora;

/**
 * @author Oscar Alvarez C.
 *
 */
public class Persona {
	
	private String rut;
	private String nombre;
	private int edad;
	
	/**
	 * @param rut
	 * @param nombre
	 * @param edad
	 */
	public Persona(String rut, String nombre, int edad) {
		super();
		this.rut = rut;
		this.nombre = nombre;
		this.edad = edad;
	}	
	public Persona() {
		
	}
	
	/**
	 * @return the rut
	 */
	public String getRut() {
		return rut;
	}
	/**
	 * @param rut the rut to set
	 */
	public void setRut(String rut) {
		this.rut = rut;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the edad
	 */
	public int getEdad() {
		return edad;
	}
	/**
	 * @param edad the edad to set
	 */
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
	
	

}
