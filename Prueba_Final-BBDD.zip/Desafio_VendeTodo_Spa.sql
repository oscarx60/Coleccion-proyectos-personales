create user "administrador" password 'admin';
grant all privileges on database "Desafio_VendeTodo_Spa" to "administrador"; -- Primero que todo, crear la base de datos "Desafio_VendeTodo_Spa"


SET check_function_bodies = false;

/* Table 'Proveedores' */
CREATE TABLE "Proveedores"(
  rut varchar NOT NULL,
  nombre_compania varchar NOT NULL,
  nombre_contacto varchar NOT NULL,
  direccion varchar NOT NULL,
  region varchar NOT NULL,
  ciudad varchar NOT NULL,
  telefono numeric NOT NULL,
  PRIMARY KEY(rut)
);

/* Table 'Despachadores' */
CREATE TABLE "Despachadores"(
  id numeric NOT NULL,
  nombre varchar NOT NULL,
  telefono_empresa numeric NOT NULL,
  PRIMARY KEY(id)
);

/* Table 'Cliente' */
CREATE TABLE "Cliente"(
  id numeric NOT NULL,
  nombre_empresa varchar NOT NULL,
  nombre_contacto varchar NOT NULL,
  email varchar NOT NULL,
  direccion varchar NOT NULL,
  region varchar NOT NULL,
  ciudad varchar NOT NULL,
  pais varchar NOT NULL,
  codigo_postal numeric NOT NULL,
  telefono numeric NOT NULL,
  PRIMARY KEY(id)
);

/* Table 'Empleados' */
CREATE TABLE "Empleados"(
  id numeric NOT NULL,
  nombre varchar NOT NULL,
  apellido varchar NOT NULL,
  fecha_nacimiento date NOT NULL,
  direccion varchar NOT NULL,
  region varchar NOT NULL,
  ciudad varchar NOT NULL,
  pais varchar NOT NULL,
  telefono numeric NOT NULL,
  cargo varchar NOT NULL,
  PRIMARY KEY(id)
);

/* Table 'Orden_de_Compra' */
CREATE TABLE "Orden_de_Compra"(
  id numeric NOT NULL,
  fecha_requerimiento date NOT NULL,
  fecha_envio date NOT NULL,
  nombre_a_quien_envia varchar NOT NULL,
  direccion varchar NOT NULL,
  codigo_postal numeric NOT NULL,
  ciudad varchar NOT NULL,
  region varchar NOT NULL,
  pais varchar NOT NULL,
  via_de_envio varchar NOT NULL,
  "Despachadores_id" numeric NOT NULL,
  "Cliente_id" numeric NOT NULL,
  PRIMARY KEY(id)
);

/* Table 'Productos' */
CREATE TABLE "Productos"(
  id numeric NOT NULL,
  precio numeric NOT NULL,
  stock numeric CHECK (stock >= 0.00) NOT NULL,
  descontinuado boolean NOT NULL,
  "Categoria_nombre_categoria" varchar NOT NULL,
  PRIMARY KEY(id)
);

/* Table 'Categoria' */
CREATE TABLE "Categoria"
  (nombre_categoria varchar NOT NULL, PRIMARY KEY(nombre_categoria));

/* Table 'Venta' */
CREATE TABLE "Venta"(
  cantidad_productos numeric NOT NULL,
  descuentos numeric NOT NULL,
  "Empleados_id" numeric NOT NULL,
  "Orden_de_Compra_id" numeric NOT NULL,
  "Productos_id" numeric NOT NULL
);

/* Table 'Compra _de_Producto' */
CREATE TABLE "Compra _de_Producto"(
  cantidad numeric NOT NULL,
  valor numeric NOT NULL,
  "Proveedores_rut" varchar NOT NULL,
  "Productos_id" numeric NOT NULL
);

/* Relation 'Categoria_Productos' */
ALTER TABLE "Productos"
  ADD CONSTRAINT "Categoria_Productos"
    FOREIGN KEY ("Categoria_nombre_categoria")
      REFERENCES "Categoria" (nombre_categoria);

/* Relation 'Proveedores_Compra _de_Producto' */
ALTER TABLE "Compra _de_Producto"
  ADD CONSTRAINT "Proveedores_Compra _de_Producto"
    FOREIGN KEY ("Proveedores_rut") REFERENCES "Proveedores" (rut);

/* Relation 'Productos_Compra _de_Producto' */
ALTER TABLE "Compra _de_Producto"
  ADD CONSTRAINT "Productos_Compra _de_Producto"
    FOREIGN KEY ("Productos_id") REFERENCES "Productos" (id);

/* Relation 'Despachadores_Orden_de_Compra' */
ALTER TABLE "Orden_de_Compra"
  ADD CONSTRAINT "Despachadores_Orden_de_Compra"
    FOREIGN KEY ("Despachadores_id") REFERENCES "Despachadores" (id);

/* Relation 'Cliente_Orden_de_Compra' */
ALTER TABLE "Orden_de_Compra"
  ADD CONSTRAINT "Cliente_Orden_de_Compra"
    FOREIGN KEY ("Cliente_id") REFERENCES "Cliente" (id);

/* Relation 'Empleados_Venta' */
ALTER TABLE "Venta"
  ADD CONSTRAINT "Empleados_Venta"
    FOREIGN KEY ("Empleados_id") REFERENCES "Empleados" (id);

/* Relation 'Orden_de_Compra_Venta' */
ALTER TABLE "Venta"
  ADD CONSTRAINT "Orden_de_Compra_Venta"
    FOREIGN KEY ("Orden_de_Compra_id") REFERENCES "Orden_de_Compra" (id);

/* Relation 'Productos_Venta' */
ALTER TABLE "Venta"
  ADD CONSTRAINT "Productos_Venta"
    FOREIGN KEY ("Productos_id") REFERENCES "Productos" (id);
   
   /*************************************/
   
INSERT INTO "Empleados" (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
VALUES (1, 'Empleado1', 'Apellido1', TO_DATE('12/02/1970','dd/mm/yyyy'), 'direccion1', 'region1','ciudad1','pais1',1234567,'Vendedor');
INSERT INTO "Empleados"  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
VALUES (2, 'Empleado2', 'Apellido2', TO_DATE('13/03/1970','dd/mm/yyyy'), 'direccion2', 'region2','ciudad2','pais2',1234568,'Programador'); 
INSERT INTO "Empleados"  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
VALUES (3, 'Empleado3', 'Apellido3', TO_DATE('14/04/1970','dd/mm/yyyy'), 'direccion3', 'region3','ciudad3','pais3',1234569,'Conserje');
INSERT INTO "Empleados"  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
VALUES (4, 'Empleado4', 'Apellido4', TO_DATE('15/05/1970','dd/mm/yyyy'), 'direccion4', 'region4','ciudad4','pais4',1234560,'Supervisor');
INSERT INTO "Empleados"  (id, nombre, apellido, fecha_nacimiento, direccion, region, ciudad, pais, telefono, cargo)
VALUES (5, 'Empleado5', 'Apellido5', TO_DATE('16/06/1970','dd/mm/yyyy'), 'direccion5', 'region5','ciudad5','pais5',1234562,'Jefe de area');
 
INSERT INTO "Cliente"(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(1, 'Empresa1', 'Contacto1', 'cliente01@hotmail.com', 'direccion6', 'region6', 'ciudad6', 'pais6', 321321, 425252);
INSERT INTO "Cliente"(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(2, 'Empresa2', 'Contacto2', 'cliente02@hotmail.com', 'direccion7', 'region7', 'ciudad7', 'pais7', 123123, 231232);
INSERT INTO "Cliente"(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(3, 'Empresa3', 'Contacto3', 'cliente03@hotmail.com', 'direccion8', 'region8', 'ciudad8', 'pais8', 450503, 232323);
INSERT INTO "Cliente"(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(4, 'Empresa4', 'Contacto4', 'cliente04@gmail.com', 'direccion9', 'region9', 'ciudad9', 'pais9', 905813, 4568412);
INSERT INTO "Cliente"(id, nombre_empresa, nombre_contacto, email, direccion, region, ciudad, pais, codigo_postal, telefono)
values(5, 'Empresa5', 'Contacto5', 'cliente05@gmail.com', 'direccion10', 'region10', 'ciudad10', 'pais10', 512345, 458741);
 
INSERT INTO "Despachadores" (id, nombre, telefono_empresa) VALUES (1, 'nombre1', 452970);
INSERT INTO "Despachadores" (id, nombre, telefono_empresa) VALUES (2, 'nombre2', 425671);
INSERT INTO "Despachadores" (id, nombre, telefono_empresa) VALUES (3, 'nombre3', 432314);
INSERT INTO "Despachadores" (id, nombre, telefono_empresa) VALUES (4, 'nombre4', 123561);
INSERT INTO "Despachadores" (id, nombre, telefono_empresa) VALUES (5, 'nombre5', 627212);
 
INSERT INTO "Categoria" (nombre_categoria) VALUES ('categoria1');
INSERT INTO "Categoria" (nombre_categoria) VALUES ('categoria2');
INSERT INTO "Categoria" (nombre_categoria) VALUES ('categoria3');
INSERT INTO "Categoria" (nombre_categoria) VALUES ('categoria4');
INSERT INTO "Categoria" (nombre_categoria) VALUES ('categoria5');
 
INSERT INTO "Proveedores" (rut,nombre_compania,nombre_contacto,direccion,region,ciudad,telefono)
VALUES ('11133134-1','Empresa1','contacto1','direccion1','region1','ciudad1',345161);
INSERT INTO "Proveedores" (rut,nombre_compania,nombre_contacto,direccion,region,ciudad,telefono)
VALUES ('11133135-2','Empresa2','contacto2','direccion2','region2','ciudad2',325416);
INSERT INTO "Proveedores" (rut,nombre_compania,nombre_contacto,direccion,region,ciudad,telefono)
VALUES ('11133136-k','Empresa3','contacto3','direccion3','region3','ciudad3',321541);
INSERT INTO "Proveedores" (rut,nombre_compania,nombre_contacto,direccion,region,ciudad,telefono)
VALUES ('11133137-3','Empresa4','contacto4','direccion4','region4','ciudad4',626712);
INSERT INTO "Proveedores" (rut,nombre_compania,nombre_contacto,direccion,region,ciudad,telefono)
VALUES ('11133138-4','Empresa5','contacto5','direccion5','region5','ciudad5',582952);
INSERT INTO "Proveedores" (rut,nombre_compania,nombre_contacto,direccion,region,ciudad,telefono)
VALUES ('11133139-5','Empresa6','contacto6','direccion6','region6','ciudad6',246161);
 
INSERT INTO "Productos" (id, precio, stock, descontinuado, "Categoria_nombre_categoria") VALUES (1, 2000, 5, TRUE, 'categoria1'); --Solo nos permite ingresar valores que ya existan en tabla categoria
INSERT INTO "Productos" (id, precio, stock, descontinuado, "Categoria_nombre_categoria") VALUES (2, 5000, 10, TRUE, 'categoria2');
INSERT INTO "Productos" (id, precio, stock, descontinuado, "Categoria_nombre_categoria") VALUES (3, 10000, 3, FALSE , 'categoria3');
INSERT INTO "Productos" (id, precio, stock, descontinuado, "Categoria_nombre_categoria") VALUES (4, 15000, 7, TRUE, 'categoria2');
INSERT INTO "Productos" (id, precio, stock, descontinuado, "Categoria_nombre_categoria") VALUES (5, 1000, 12, TRUE, 'categoria5');
 
INSERT INTO "Orden_de_Compra" (id, "Despachadores_id", "Cliente_id", fecha_requerimiento, fecha_envio, nombre_a_quien_envia, direccion, codigo_postal, ciudad, region, pais, via_de_envio)
VALUES (1, 1, 1, TO_DATE('12/02/2020','dd/mm/yyyy'), TO_DATE('15/02/2020','dd/mm/yyyy'), 'nombre1', 'direccion1', '323135','ciudad1','region1','pais1','camion');
INSERT INTO "Orden_de_Compra" (id, "Despachadores_id", "Cliente_id", fecha_requerimiento, fecha_envio, nombre_a_quien_envia, direccion, codigo_postal, ciudad, region, pais, via_de_envio)
VALUES (2, 5, 4, TO_DATE('17/05/2020','dd/mm/yyyy'), TO_DATE('20/05/2020','dd/mm/yyyy'), 'nombre2', 'direccion2', '361772','ciudad2','region2','pais2','express');
INSERT INTO "Orden_de_Compra" (id, "Despachadores_id", "Cliente_id", fecha_requerimiento, fecha_envio, nombre_a_quien_envia, direccion, codigo_postal, ciudad, region, pais, via_de_envio)
VALUES (3, 4, 3, TO_DATE('20/04/2020','dd/mm/yyyy'), TO_DATE('21/04/2020','dd/mm/yyyy'), 'nombre3', 'direccion3', '312461','ciudad3','region3','pais3','aerea');
INSERT INTO "Orden_de_Compra" (id, "Despachadores_id", "Cliente_id", fecha_requerimiento, fecha_envio, nombre_a_quien_envia, direccion, codigo_postal, ciudad, region, pais, via_de_envio)
VALUES (4, 4, 3, TO_DATE('23/07/2020','dd/mm/yyyy'), TO_DATE('24/07/2020','dd/mm/yyyy'), 'nombre4', 'direccion4', '561234','ciudad4','region4','pais4','aerea');
INSERT INTO "Orden_de_Compra" (id, "Despachadores_id", "Cliente_id", fecha_requerimiento, fecha_envio, nombre_a_quien_envia, direccion, codigo_postal, ciudad, region, pais, via_de_envio)
VALUES (5, 3, 1, TO_DATE('25/03/2020','dd/mm/yyyy'), TO_DATE('28/03/2020','dd/mm/yyyy'), 'nombre5', 'direccion5', '325165','ciudad5','region5','pais5','maritima');


INSERT INTO "Compra _de_Producto"("Proveedores_rut","Productos_id",cantidad,valor)
VALUES ('11133134-1',1, 50, 5000);
INSERT INTO "Compra _de_Producto"("Proveedores_rut","Productos_id",cantidad,valor)
VALUES ('11133135-2',2, 20, 10000);
INSERT INTO "Compra _de_Producto"("Proveedores_rut","Productos_id",cantidad,valor)
VALUES ('11133136-k',3, 25, 25000);
INSERT INTO "Compra _de_Producto"("Proveedores_rut","Productos_id",cantidad,valor)
VALUES ('11133137-3',4, 60, 3000);
INSERT INTO "Compra _de_Producto"("Proveedores_rut","Productos_id",cantidad,valor)
VALUES ('11133138-4',5, 100, 50000);
INSERT INTO "Compra _de_Producto"("Proveedores_rut","Productos_id",cantidad,valor)
VALUES ('11133139-5',3, 21, 3125);
 
INSERT INTO "Venta" ("Empleados_id", "Productos_id","Orden_de_Compra_id",cantidad_productos,descuentos)
VALUES (1, 1, 1, 3, 0.3);
INSERT INTO "Venta" ("Empleados_id", "Productos_id","Orden_de_Compra_id",cantidad_productos,descuentos)
VALUES (2, 2, 2, 5, 0.1);
INSERT INTO "Venta" ("Empleados_id", "Productos_id","Orden_de_Compra_id",cantidad_productos,descuentos)
VALUES (3, 3, 3, 2, 0.3);
INSERT INTO "Venta" ("Empleados_id", "Productos_id","Orden_de_Compra_id",cantidad_productos,descuentos)
VALUES (4, 4, 4, 1, 0.2);
INSERT INTO "Venta" ("Empleados_id", "Productos_id","Orden_de_Compra_id",cantidad_productos,descuentos)
VALUES (5, 5, 5, 5, 0);
INSERT INTO "Venta" ("Empleados_id", "Productos_id","Orden_de_Compra_id",cantidad_productos,descuentos)
VALUES (5, 3, 5, 5, 0);

select * from "Categoria";
select * from "Cliente";
select * from "Compra _de_Producto";
select * from "Despachadores";
select * from "Empleados";
select * from "Orden_de_Compra";
select * from "Productos";
select * from "Proveedores";
select * from "Venta";

select cl.id as "id cliente", 
cl.ciudad as "Ciudad",
cl.nombre_empresa as "Empresa", 
sum((v.cantidad_productos * p.precio) * (1-v.descuentos)) as "Monto total de venta"
from "Cliente" as cl
inner join "Orden_de_Compra" as o on cl.id = o."Cliente_id" 
inner join "Venta" as v on v."Orden_de_Compra_id" = o.id
inner join "Productos" as p on v."Productos_id" = p.id 
group by "id cliente", "Ciudad" 
order by "Monto total de venta" desc;

select cdp."Proveedores_rut",
p2.nombre_compania as "Nombre Empresa", 
v."Productos_id" as "Id Productos",
sum (v.cantidad_productos) as "Cantidad Total"
from "Compra _de_Producto" cdp
inner join "Productos" as p on p.id = cdp."Productos_id"
inner join "Venta" as v on v."Productos_id" = p.id
inner join "Proveedores" as p2 on p2.rut = cdp."Proveedores_rut" 
group by cdp."Proveedores_rut", v."Productos_id", p2.nombre_compania 
order by "Cantidad Total" desc;









