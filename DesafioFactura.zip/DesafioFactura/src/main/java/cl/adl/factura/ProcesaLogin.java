package cl.adl.factura;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ProcesaLogin
 */
@WebServlet("/ProcesaLogin")
public class ProcesaLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProcesaLogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	private final String LOGIN = "UsuarioRegistrado";
	private final String PASS = "admin";

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String requestLogin = "";
		String requestPass = "";

		PrintWriter out = response.getWriter();

		requestLogin = request.getParameter("usuario");
		requestPass = request.getParameter("pass");

		if (LOGIN.contentEquals(requestLogin) && (PASS.contentEquals(requestPass))) {
			HttpSession sesionUsuario = request.getSession(true);
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		} else {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Usuario o password incorrecto');");
			out.println("location='login.jsp';");
			out.println("</script>");
		}
	}

}
