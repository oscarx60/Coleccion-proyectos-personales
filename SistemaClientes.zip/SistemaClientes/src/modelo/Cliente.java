/**
 * 
 */
package modelo;

/**
 * @author Oscar Alvarez
 *
 */
public class Cliente {

	private String runCliente;
	private String nombreCliente;
	private String apellidoCliente;
	private String aniosCliente;
	
	//_________Constructor con par�metros_______
	/**
	 * @param runCliente
	 * @param nombreCliente
	 * @param apellidoCliente
	 * @param aniosCliente
	 */
	public Cliente(String runCliente, String nombreCliente, String apellidoCliente, String aniosCliente) {
		super();
		this.runCliente = runCliente;
		this.nombreCliente = nombreCliente;
		this.apellidoCliente = apellidoCliente;
		this.aniosCliente = aniosCliente;
	}
	
	//_____Constructor vac�o_____
	public Cliente() {
		
	}

	//_____Getters y Setters_____
	/**
	 * @return the runCliente
	 */
	public String getRunCliente() {
		return runCliente;
	}

	/**
	 * @param runCliente the runCliente to set
	 */
	public void setRunCliente(String runCliente) {
		this.runCliente = runCliente;
	}

	/**
	 * @return the nombreCliente
	 */
	public String getNombreCliente() {
		return nombreCliente;
	}

	/**
	 * @param nombreCliente the nombreCliente to set
	 */
	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	/**
	 * @return the apellidoCliente
	 */
	public String getApellidoCliente() {
		return apellidoCliente;
	}

	/**
	 * @param apellidoCliente the apellidoCliente to set
	 */
	public void setApellidoCliente(String apellidoCliente) {
		this.apellidoCliente = apellidoCliente;
	}

	/**
	 * @return the aniosCliente
	 */
	public String getAniosCliente() {
		return aniosCliente;
	}

	/**
	 * @param aniosCliente the aniosCliente to set
	 */
	public void setAniosCliente(String aniosCliente) {
		this.aniosCliente = aniosCliente;
	}

	//________ToString________
	@Override
	public String toString() {
		return "Cliente [runCliente=" + runCliente + ", nombreCliente=" + nombreCliente + ", apellidoCliente="
				+ apellidoCliente + ", aniosCliente=" + aniosCliente + "]";
	}
	
	
	
}
