$(document).ready(function () {
    

    $('#cons').on('click', function () {

        var id = $('#inputPoke').val();
        if (id<1) {
            id=1;
        }
        if (id>898) {
            id=898;
        }

        search(id);
        $('#inputPoke').val(id);
        

    });

    $('#retr').on('click', function () {

        var id = $('#inputPoke').val();
        id--;
        if (id<1) {
            id=1;
        }
        search(id);
        $('#inputPoke').val(id);

    });

    $('#avan').on('click', function () {

        var id = $('#inputPoke').val();
        id++;
        if (id>898) {
            id=898;
        }
        search(id);
        $('#inputPoke').val(id);

    });

    search(25);


//----------------------------------------------------------- Buscar 
        function search(id) {
            $.ajax({
                type: "GET",
                url: "https://pokeapi.co/api/v2/pokemon/" + id,
                dataType: "json",
                success: function (pokemon) {
                   // console.log(pokemon.stats)
                    var name = (pokemon.name);
                    name+=' - ' + pokemon.id
                    var laimg = pokemon.sprites.other.dream_world.front_default;
                    
                    $('#nombre').text(name);

                    console.log("Imagen: " + laimg);
                    if (laimg==null) {
                        laimg="assets/img/Nohay.png";
                        console.log("Sin Imagen: " + laimg);
                    }
                    $('#laimagen').attr('src', laimg);
                    
                    var datos = pokemon.stats;
                    grafico(datos);
                
    
                },
                error: function() {
                    console.log("Imagen: " + laimg);
                }
            });
        }
//-------------------------------------------------------

    function grafico(datos) {   // ---- Graficar

        var dataPoints = [];

        var options = {
            animationEnabled: true,
            theme: "light2",
            title: {
                text: "Abilities",
                fontColor: "orange",
            },
            legend: {
                cursor: "pointer",
                reversed: true,
                maxWidth: 250,
                itemWidth: 100,
                markerMargin: 10,
                fontColor: "black",
                dockInsidePlotArea: false,
                verticalAlign: "top",
                horizontalAlign: "left",
            },
            data: [{
                type: "pie", 
                showInLegend: true,
                toolTipContent: "{y} - #percent %",
			    legendText: "{indexLabel}",
                dataPoints: dataPoints
            }]
        };
        

        datos.forEach(function(d) {
            dataPoints.push({
                indexLabel: d.stat.name,
                y: d.base_stat,
            })
        });
        
        $("#chartContainer").CanvasJSChart(options);
    }
    //----------------------------------------------------------------- Graficar Fin

    
});