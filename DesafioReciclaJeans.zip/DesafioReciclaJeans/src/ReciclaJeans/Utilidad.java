/**
 *
 */
package ReciclaJeans;
/**
 * @author Oscar Alvarez C. 
 *
 */
public class Utilidad {

	public static void EsperaYLimpieza() {

		espera();
		limpiar();

	}

	public static void limpiar() {
		for(int i = 0; i < 10; i++) {
			System.out.println("");
		}
		System.out.flush();
	}

	public static void espera() {
		int temporizador = 10;
		try {
			for(int i = 0; i<temporizador; i++) {
				Thread.sleep(250); // El hilo actual se detiene por (x) milisegundos
			}
		}catch (InterruptedException e) { //Exception ocurrida cuando se interrumpe thread.sleep
			System.out.println("Tiempo de espera interrumpido");

		}
	}
}
