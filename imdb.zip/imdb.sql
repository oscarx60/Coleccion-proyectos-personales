create database imdb;

create table usuario_imdb (
id serial primary key not null,
usuario varchar(45),
email varchar(45),
pass varchar(45),
passverificacion varchar(45)
);

create table serie (
id serial primary key not null,
title varchar(45),
red varchar(45),
rating numeric(20)
);

select * from usuario_imdb ;
select * from serie;

insert into usuario_imdb(usuario, email, pass, passverificacion) values('Gabrek', 'ignacio.thomson.97@gmail.com', '12345@', '12345@');
insert into serie(title, red, rating) values('Vikingos', 'Netflix', 4.8);


