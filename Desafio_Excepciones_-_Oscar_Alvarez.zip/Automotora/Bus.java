/**
 * 
 */
package Automotora;

/**
 * @author Oscar Alvarez C.
 *
 */
public class Bus extends Vehiculo {
	
	protected int cantidadDeAsientos;

	/**
	 * @return the cantidadDeAsientos
	 */

	public int getCantidadDeAsientos() {
		return cantidadDeAsientos;
	}

	/**
	 * @param color
	 * @param patente
	 * @param cantidadDeAsientos
	 */
	public Bus(String color, String patente, int cantidadDeAsientos) {
		super(color, patente);
		this.cantidadDeAsientos = cantidadDeAsientos;
	}
	
	public Bus() {
		
	}

	/**
	 * @param cantidadDeAsientos the cantidadDeAsientos to set
	 */
	public void setCantidadDeAsientos(int cantidadDeAsientos) {
		this.cantidadDeAsientos = cantidadDeAsientos;
	}
	
	public int asientosDisponibles() {
		
		return cantidadDeAsientos;
		
	}
	
	

}
