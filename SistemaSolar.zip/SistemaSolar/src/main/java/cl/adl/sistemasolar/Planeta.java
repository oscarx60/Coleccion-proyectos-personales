package cl.adl.sistemasolar;

import java.util.ArrayList;

public class Planeta {
	
	private String nombre;
	private String tama�o;
	private String distanciaAlSol;
	private String distanciaALuna;
	private ArrayList<Luna> luna;
	private ArrayList<Luna> luna2;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTama�o() {
		return tama�o;
	}
	public void setTama�o(String tama�o) {
		this.tama�o = tama�o;
	}
	public String getDistanciaAlSol() {
		return distanciaAlSol;
	}
	public void setDistanciaAlSol(String distanciaAlSol) {
		this.distanciaAlSol = distanciaAlSol;
	}
	public String getDistanciaALuna() {
		return distanciaALuna;
	}
	public void setDistanciaALuna(String distanciaALuna) {
		this.distanciaALuna = distanciaALuna;
	}
	
	public ArrayList<Luna> getLuna() {
		return luna;
	}
	public void setLuna(ArrayList<Luna> luna) {
		this.luna = luna;
	}
	
	public ArrayList<Luna> getLuna2() {
		return luna2;
	}
	public void setLuna2(ArrayList<Luna> luna2) {
		this.luna2 = luna2;
	}
	
	@Override
	public String toString() {
		return "El planeta " + nombre + ", su tama�o es de " + tama�o + ", se encuentra a " + distanciaAlSol + " del Sol"
				+ ", su distancia con su(s) luna(s) es " + distanciaALuna + ", su primera luna es " + luna + " y su segunda luna " + luna2;
	}

}
