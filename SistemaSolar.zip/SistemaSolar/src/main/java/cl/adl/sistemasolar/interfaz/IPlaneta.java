package cl.adl.sistemasolar.interfaz;

import java.util.ArrayList;

import cl.adl.sistemasolar.Luna;
import cl.adl.sistemasolar.Planeta;

public interface IPlaneta {
	
	public Planeta construirPlaneta(String nombre, String tama�o, String distanciaAlSol, String distanciaALuna, ArrayList<Luna> luna, ArrayList<Luna> luna2);

}
