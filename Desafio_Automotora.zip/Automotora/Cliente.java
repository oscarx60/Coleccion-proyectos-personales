/**
 * 
 */
package Automotora;

/**
 * @author Oscar Alvarez C. 
 *
 */
public class Cliente extends Persona {
	
	private int edad;

	/**
	 * @param rut
	 * @param nombre
	 * @param edad
	 * @param edad2
	 */
	public Cliente(String rut, String nombre, int edad, int edad2) {
		super(rut, nombre, edad);
		edad = edad2;
	}
	
	public Cliente() {
		
	}

	/**
	 * @return the edad
	 */
	public int getEdad() {
		return edad;
	}

	/**
	 * @param edad the edad to set
	 */
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
	
	
	

}
