module SoloPares {
}