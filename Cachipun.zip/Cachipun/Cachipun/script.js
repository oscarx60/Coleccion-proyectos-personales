function play() {
    const posibilities = [ 'piedra', 'papel', 'tijeras' ]; 
    const p1   = document.getElementById("player1").value;
    const p2   = posibilities[ Math.floor(Math.random() * posibilities.length) ];
    
    if( !p1 ) return;
    if (p1 === p2) {
        alert('¡Empate!');
    } else if(p1 === "papel" && p2 === "piedra") {
        alert("¡Felicitaciones, has ganado contra la máquina!")
    } else if (p1 === "tijeras" && p2 === "papel") {
        alert("¡Felicitaciones, has ganado contra la máquina!")
    } else if (p1 === "tijera" && p2 === "papel") {
        alert("¡Felicitaciones, has ganado contra la máquina!")
    } else if (p1 === "piedra" && p2 === "tijeras") {
       alert("¡Felicitaciones, has ganado contra la máquina!")
    } else if (p1 === "piedra" && p2 === "tijera") {
        alert("¡Felicitaciones, has ganado contra la máquina!")
    } else {
        alert("Lo lamentamos, has perdido contra la máquina, vuelve a intentarlo")
    }
  
  }

  