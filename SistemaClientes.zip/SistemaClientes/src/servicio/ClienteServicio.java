/**
 * 
 */
package servicio;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthScrollBarUI;

import modelo.Cliente;
import utilidades.Utilidad;

/**
 * @author Oscar Alvarez
 *
 */
public class ClienteServicio {

	List<Cliente> listaClientes;

	//_______Constructor_______
	public ClienteServicio() {
		listaClientes = new ArrayList<>();
	}

	public void listarClientes() {
		if (listaClientes.size()!=0) {

			for (Cliente cliente : listaClientes) {
				System.out.println("-------------Datos del Cliente-------------");
				System.out.println();
				System.out.println("RUN del Cliente: "+ cliente.getRunCliente());
				System.out.println("Nombre del Cliente: "+ cliente.getNombreCliente());
				System.out.println("Apellido del Cliente: "+ cliente.getApellidoCliente());
				System.out.println("A�os como Cliente: "+ cliente.getAniosCliente());
				System.out.println();
			}

		}else {
			System.out.println("Su lista no puede inicializar, no existe cliente");
		}
		Utilidad.EsperaYLimpieza();
	}

	public void agregarCliente(String nombreCliente, String apellidoCliente, String runCliente, String aniosCliente) {
		Cliente cliente = new Cliente(nombreCliente, apellidoCliente, runCliente, aniosCliente);
		if (listaClientes!=null) {
			listaClientes.add(cliente);
			System.out.println("Cliente agregado correctamente\n");
		}else {
			System.out.println("No se puede agregar elemento a la lista debido a que esta no existe");
		}
		
		Utilidad.EsperaYLimpieza();
	}
	public void editarCliente(String runCliente, String nombreCliente, String apellidoCliente, String aniosCliente, Cliente cliente) {
		Scanner miScanner = new Scanner(System.in);
		boolean continuar = false;
		do {
			System.out.println("1. El Run del cliente es:" + cliente.getRunCliente());
			System.out.println("2. El Nombre del cliente es:" + cliente.getNombreCliente());
			System.out.println("3. El Apellido del cliente es:" + cliente.getApellidoCliente());
			System.out.println("4. Los A�os como cliente son:" + cliente.getAniosCliente());
			System.out.println();
			System.out.println("Ingrese opcion a editar de los datos del cliente:");
			System.out.println("Pulse 5 para salir");
			
			String opcion = miScanner.nextLine();
			switch (opcion) {
			case "1":
				System.out.println("Ingrese nuevo run del cliente:");
				cliente.setRunCliente(miScanner.nextLine());
				System.out.println("Run Cliente fue editado con �xito\n");
				break;
			case "2":
				System.out.println("Ingrese nuevo nombre del cliente:");
				cliente.setNombreCliente(miScanner.nextLine());
				System.out.println("Nombre Cliente fue editado con �xito");
				break;
			case "3":
				System.out.println("Ingrese nuevo apellido del cliente:");
				cliente.setApellidoCliente(miScanner.nextLine());
				System.out.println("Apellido cliente fue editado con �xito");
				break;
			case "4":
				System.out.println("Ingrese nueva cantidad de a�os del cliente:");
				cliente.setAniosCliente(miScanner.nextLine());
				System.out.println("A�os del cliente editado con �xito");
				break;
			case "5":
				System.out.println("Saliendo de editar cliente");
				continuar = true;
				break;

			default:
				System.out.println("Opci�n err�nea");
				break;
			}
		} while (!continuar);
	}

	/**
	 * @return the listaClientes
	 */
	public List<Cliente> getListaClientes() {
		return listaClientes;
	}

	/**
	 * @param listaClientes the listaClientes to set
	 */
	public void setListaClientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}



}
