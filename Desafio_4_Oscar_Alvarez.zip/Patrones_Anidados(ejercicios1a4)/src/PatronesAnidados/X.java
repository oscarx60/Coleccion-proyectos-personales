package PatronesAnidados;

public class X {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
