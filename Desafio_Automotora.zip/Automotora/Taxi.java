/**
 * 
 */

package Automotora;

import java.util.Scanner;

/**
 * @author Oscar Alvarez C.
 *
 */

public class Taxi {

	private int valorPasaje;

	/**
	 * @param valorPasaje
	 */
	public Taxi(int valorPasaje) {
		super();
		this.valorPasaje = valorPasaje;
	}
	
	public Taxi() {
		
	}

	/**
	 * @return the valorPasaje
	 */
	public int getValorPasaje() {
		return valorPasaje;
	}

	/**
	 * @param valorPasaje the valorPasaje to set
	 */
	public void setValorPasaje(int valorPasaje) {
		this.valorPasaje = valorPasaje;
	}

	public void pagarPasaje(){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese cantidad de dinero a pagar");
		int dinero = sc.nextInt();
		
		if(dinero>valorPasaje) {
			
			int vuelto = dinero-valorPasaje;
			System.out.println("Su vuelto es: " + vuelto);
			
			
		}
		else if(dinero<valorPasaje) {
			System.out.println("El dinero no alcanza" + valorPasaje);
			
		}
		
		else if(dinero==valorPasaje) {
			System.out.println("Gracias por su preferencia");
		}
		
		sc.close();
	}

}
