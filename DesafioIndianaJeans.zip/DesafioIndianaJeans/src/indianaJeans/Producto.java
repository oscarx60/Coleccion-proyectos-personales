/**
 *
 */
package indianaJeans;
 
/**
 * @author Oscar Alvarez C.
 *
 */
public class Producto {
   
    private String articulo;
    private String precio;
    private String descripcion;
    private String codigo;
    private String talla;
    private String marca;
    private String color;
   
    /**
     * @param articulo
     * @param precio
     * @param descripcion
     * @param codigo
     * @param talla
     * @param marca
     * @param color
     */
    public Producto(String articulo, String codigo, String color, String descripcion, String marca, String precio,
            String talla) {
        super();
        this.articulo = articulo;
        this.precio = precio;
        this.descripcion = descripcion;
        this.codigo = codigo;
        this.talla = talla;
        this.marca = marca;
        this.color = color;
    }
    public Producto() {
       
    }
   
    /**
     * @return the articulo
     */
    public String getArticulo() {
        return articulo;
    }
    /**
     * @param articulo the articulo to set
     */
    public void setArticulo(String articulo) {
        this.articulo = articulo;
    }
    /**
     * @return the precio
     */
    public String getPrecio() {
        return precio;
    }
    /**
     * @param precio the precio to set
     */
    public void setPrecio(String precio) {
        this.precio = precio;
    }
    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }
    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    /**
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }
    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    /**
     * @return the talla
     */
    public String getTalla() {
        return talla;
    }
    /**
     * @param talla the talla to set
     */
    public void setTalla(String talla) {
        this.talla = talla;
    }
    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }
    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }
    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }
    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }
    @Override
    public String toString() {
        return "Producto [articulo=" + articulo + ", precio=" + precio + ", descripcion=" + descripcion + ", codigo="
                + codigo + ", talla=" + talla + ", marca=" + marca + ", color=" + color + "]";
    }
   

 
}
