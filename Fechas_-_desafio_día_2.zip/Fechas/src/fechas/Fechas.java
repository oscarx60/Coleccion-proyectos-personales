package fechas;

import java.util.Scanner;

public class Fechas {

	public static void main(String[] args) {
		
		String fecha1 = "";
		String fecha2 = "";
		
		Scanner sc = new Scanner(System.in);
		System.out.printf("Ingrese la primera fecha como DD/MM/AAAA ");
		fecha1 = sc.nextLine();
		System.out.printf("Ingrese la segunda fecha como DD/MM/AAAA ");
		fecha2 = sc.nextLine();
		
		String fecha1D = fecha1.substring(0, 2);
		String fecha1M = fecha1.substring(3, 5);
		String fecha1A = fecha1.substring(6,10);
		String fecha2D = fecha2.substring(0, 2);
		String fecha2M = fecha2.substring(3, 5);
		String fecha2A = fecha2.substring(6, 10);
		
		int diasFecha1 = Integer.parseInt(fecha1D);
		int mesesFecha1 = Integer.parseInt(fecha1M);
		int anioFecha1 = Integer.parseInt(fecha1A);
		int diasFecha2 = Integer.parseInt(fecha2D);
		int mesesFecha2 = Integer.parseInt(fecha2M);
		int anioFecha2 = Integer.parseInt(fecha2A);
		
		if (anioFecha1 < anioFecha2) {
			System.out.printf("persona 1 es mayor ");
		} else if (anioFecha2 < anioFecha1) {
			System.out.printf("persona 2 es mayor ");
		} else {
			if (mesesFecha1 < mesesFecha2) {
				System.out.printf("persona 1 es mayor ");
			} else if (mesesFecha2 < mesesFecha1) {
				System.out.printf("persona 2 es mayor ");
			} else {
				if (diasFecha1 < diasFecha2) {
					System.out.printf("persona 1 es mayor ");
				} else if (diasFecha2 < diasFecha1) {
					System.out.printf("persona 2 es mayor ");
				} else {
					System.out.printf("Tienen la misma edad ");
				}
			}
		}
	}
}
