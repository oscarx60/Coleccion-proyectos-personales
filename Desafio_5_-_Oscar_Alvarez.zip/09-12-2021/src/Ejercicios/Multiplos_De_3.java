package Ejercicios;

public class Multiplos_De_3 {
    
    static boolean isDivisibleBy3(int num) {
            if(num % 3 == 0) {
                return true;
            }
 
            else {
                return false;
            }
    }
 
    static long suma(int[] nums) {
        long sum = 0;
        for(int i = 0; i < nums.length; i++) {
            if(isDivisibleBy3(nums[i])) {
                sum += nums[i];
            }
 
            else {
                continue;
            }
        }
        return sum;
    }
 
 
    static float promedio(int[] nums) {
        int counter = 0;
        for(int i = 0; i < nums.length; i++) {
            if(isDivisibleBy3(nums[i])) {
                counter++;
            }
 
            else {
                continue;
            }
        }
 
        float average = suma(nums) / counter;
        return average;
    }
    public static void main(String[] args) {
 
        int[] nums = new int[args.length];
 
        for(int i = 0; i < args.length; i++) {
            nums[i] = Integer.parseInt(args[i]);
        }
 
        System.out.print("La suma de los multiplos de 3 contenidos en la lista es: ");
        System.out.println(suma(nums));
 
        System.out.print("El promedio de los m�ltiplos de 3 contenidos en la lista es: ");
        System.out.println(promedio(nums));
    }
}