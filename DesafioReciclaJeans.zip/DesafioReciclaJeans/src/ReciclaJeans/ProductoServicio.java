/**
 *
 */
package ReciclaJeans;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Oscar Alvarez C. 
 *
 */
public class ProductoServicio {

	List <Producto> listaProductos;

	/**
	 * @param listaProductos
	 */
	public ProductoServicio(List<Producto> listaProductos) {
		super();
		this.listaProductos = listaProductos;
	}

	public ProductoServicio() {
		listaProductos = new ArrayList<>();
	}


	/**
	 * @return the listaProductos
	 */
	public List<Producto> getListaProductos() {
		return listaProductos;
	}

	/**
	 * @param listaProductos the listaProductos to set
	 */
	public void setListaProductos(List<Producto> listaProductos) {
		this.listaProductos = listaProductos;
	}

	public void listarProductos(){

		if(listaProductos.size()!=0) { //Confirmo si la lista no esta vacia

			for(Producto producto: listaProductos){

				System.out.println("Datos de producto" +"\n");
				System.out.println("Nombre: " + producto.getArticulo());
				System.out.println("Codigo: " + producto.getCodigo());
				System.out.println("Color: " + producto.getColor());
				System.out.println("Descripcion: " +producto.getDescripcion());
				System.out.println("Marca: " +producto.getMarca());
				System.out.println("Precio: " +producto.getPrecio());
				System.out.println("Talla: " +producto.getTalla());
			}

		}else {
			System.out.println("Su lista no puede inicializarce o presento un error\n");
		}
		Utilidad.EsperaYLimpieza();
	}



	public void agregarProductos(String articulo, String codigo, String color, String descripcion, String marca, String precio, String talla) {

		Producto producto = new Producto (articulo, codigo, color, descripcion, marca, precio, talla);

		if(listaProductos!=null) {
			listaProductos.add(producto);
			System.out.println("Producto agregado correctamente\n");
		}else {
			System.out.println("No pudo agregarse elemento a la lista debido a que esta no existe.");
		}
		Utilidad.EsperaYLimpieza();

	}

}
