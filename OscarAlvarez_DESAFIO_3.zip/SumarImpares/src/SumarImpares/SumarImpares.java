package SumarImpares;

import java.util.Scanner;

public class SumarImpares {
	
	/*El siguiente codigo me va a sumar los numeros impares dentro de una sucesion de numeros, 
	solo ingresando el numero limite por consola*/

	public static void main(String[] args) {
		System.out.println("Ingrese un n�mero");
		Scanner sc = new Scanner(System.in);
		int numero = sc.nextInt();
		//i es la variable que contar� hasta el n�mero ingresado
		int i = 0;
		//suma es la variable que ir� guardando el resultado
		int suma = 0;
		while (i < numero){
			i+=1;
			if(i%2 == 1) { // es impar
				suma += i;
			}
		}
		System.out.printf("%d\n",suma);
	}



}


