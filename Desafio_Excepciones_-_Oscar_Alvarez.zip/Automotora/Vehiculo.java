/**
 * 
 */

package Automotora;

/**
 * @author Oscar Alvarez C.
 *
 */

public class Vehiculo {

	protected String color;
	protected String patente;

	/**
	 * @param color
	 * @param patente
	 */
	public Vehiculo(String color, String patente) {
		super();
		this.color = color;
		this.patente = patente;
	}

	public Vehiculo() {

	}
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return the patente
	 */
	public String getPatente() {
		return patente;
	}
	/**
	 * @param patente the patente to set
	 */
	public void setPatente(String patente) {
		this.patente = patente;
	}






}
