package cl.adl.profe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeguridadDia1Application {

	public static void main(String[] args) {
		SpringApplication.run(SeguridadDia1Application.class, args);
	}

}
