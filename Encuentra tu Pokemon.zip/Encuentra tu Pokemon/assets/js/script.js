$(document).ready(function () {

    $('button').on('click', function () {// con esto escuchamos el "button" hasta hacer click
        var userInput = $(".form-control").val();
        var url = "https://pokeapi.co/api/v2/pokemon/" + userInput;
        
        $.ajax(
            {
                type: "GET",
                url: url,
                dataType: "json",

                success: function (Pokedata) {//"success"--->cuando resulta exitoso

                    for(var i=0; i<Pokedata.stats.length; i++) {
                        console.log(Pokedata.stats[i]);
                                
                    }
                    
                  
                    $('#pokeimage').attr("src", Pokedata.sprites.front_default);
                    $('.card-title').text(Pokedata.species.name);
                    $('#peso').text("Peso: " + Pokedata.weight);
                    $('#altura').text("Altura: " + Pokedata.height);
                    //$('#tipo').text("Tipo: " + Pokedata.type.name);
                    $('#numero').text("N° Pokedex: " + Pokedata.id);
                },

                error: function () {
                    console.log("hicimos la morición");
                }

            }
        )
    });
});


function grafico(datos) {   // ---- Graficar

    var dataPoints = [];

    var options = {
        animationEnabled: true,
        theme: "light2",
        title: {
            text: "Abilities",
            fontColor: "orange",
        },
        legend: {
            cursor: "pointer",
            reversed: true,
            maxWidth: 250,
            itemWidth: 100,
            markerMargin: 10,
            fontColor: "black",
            dockInsidePlotArea: false,
            verticalAlign: "top",
            horizontalAlign: "left",
        },
        data: [{
            type: "pie", 
            showInLegend: true,
            toolTipContent: "{y} - #percent %",
            legendText: "{indexLabel}",
            dataPoints: dataPoints
        }]
    };
    

    datos.forEach(function(d) {
        dataPoints.push({
            indexLabel: d.stat.name,
            y: d.base_stat,
        })
    });
    
    $("#chartContainer").CanvasJSChart(options);
}
//----------------------------------------------------------------- Graficar Fin