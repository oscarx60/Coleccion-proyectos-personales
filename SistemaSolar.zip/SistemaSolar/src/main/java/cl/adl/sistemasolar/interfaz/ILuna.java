package cl.adl.sistemasolar.interfaz;

import java.util.ArrayList;

import cl.adl.sistemasolar.Luna;

public interface ILuna {
	
	public ArrayList<Luna>construirLuna(String nombre, String diametro, String tiempoOrbita);

}
