
var form = document.getElementById("formulario");
form.addEventListener("submit", function(event){
    
    limpiarErrores();
    event.preventDefault();
    let nombre = document.getElementById("nombre").value;
    let asunto = document.getElementById("asunto").value;
    let mensaje = document.getElementById("mensaje").value;

    let resultado = validarDatos(nombre, asunto, mensaje);

    if (resultado == true) {
        ingresoCorrecto();

    };
});
function limpiarErrores() {
    document.querySelector(".resultado").innerHTML=" ";
    document.querySelector(".errorNombre").innerHTML=" ";
    document.querySelector(".errorAsunto").innerHTML=" ";
    document.querySelector(".errorMensaje").innerHTML=" ";
};

function ingresoCorrecto() {
    document.querySelector(".resultado").innerHTML="Mensaje enviado con éxito";
};
function validarDatos (nombre, asunto, mensaje) {
    let validacionOk = true;
    let validacionNombre = /[a-zA-Z]/gim;

    if (validacionNombre.test(nombre)==false) {
        document.querySelector(".errorNombre").innerHTML="El nombre es requerido";
        validacionOk = false;
    };

    let validacionAsunto = /[a-zA-Z]/gim;
    if (validacionAsunto.test(asunto)==false) {
        document.querySelector(".errorAsunto").innerHTML="El asunto es requerido";
        validacionOk = false;
    };

    let validacionMensaje = /[a-zA-Z]/gim;
    if (validacionMensaje.test(mensaje)==false) {
        document.querySelector(".errorMensaje").innerHTML="El mensaje es requerido";
        validacionOk = false;

};

return validacionOk;

};


