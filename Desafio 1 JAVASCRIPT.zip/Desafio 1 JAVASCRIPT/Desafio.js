// Titulos en HTML pal cache
document.write("<div style=\"border: solid; 5px; blue;\">")
document.write("<p style=\"font-size:30px\">DESAFIO JS 001 </p>")

//----------------------------------------------------------------------------------------------------------------
//2. Realizar operaciones con dos números.
//----------------------------------------------------------------------------------------------------------------
document.write("<p style=\"font-size:20px; border-bottom: solid 3px black; border-top: solid 9px blue;\">2. Realizar operaciones con dos números. </p>")
//Pedida de numbers N1
var n1 = parseInt(prompt("Ingresa un primer number : "));

while (n1==0) {
    var n1 = parseInt(prompt("Ingresa un primer number : "));
}
//Pedida de numbers N2
var n2 = parseInt(prompt("Ingresa un segundo number : "));

while (n2==0) {
    var n2 = parseInt(prompt("Ingresa un segundo number : "));
}

//La suma
document.write("<p style=\"font-size: 18x; color: green;\">La suma de  : " + n1 + " con " + n2 + " es de ==>> " + (n1+n2) + "</p>")
//La resta
document.write("<p style=\"font-size: 18x; color: blue;\">La resta de  : " + n1 + " con " + n2 + " es de ==>> " + (n1-n2) + "</p>")
//La multiplicacion
document.write("<p style=\"font-size: 18x; color: red;\">La multiplicacion de  : " + n1 + " con " + n2 + " es de ==>> " + (n1*n2) + "</p>")
//La division
document.write("<p style=\"font-size: 18x; color: orange;\">La division de  : " + n1 + " con " + n2 + " es de ==>> " + (n1/n2) + "</p>")
//El moudlo
document.write("<p style=\"font-size: 18x; color: magenta;\">El modulo de  : " + n1 + " con " + n2 + " es de ==>> " + (n1%n2) + "</p>")


//----------------------------------------------------------------------------------------------------------------
//3. Crear un programa que pida al usuario ingresar la temperatura en grados Celsius
//----------------------------------------------------------------------------------------------------------------
document.write("<p style=\"font-size:20px; border-bottom: solid 3px black; border-top: solid 9px blue;\">3. Crear un programa que pida al usuario ingresar la temperatura en grados Celsius. </p>")
//Pedida de gados celcius c1
var c1 = parseInt(prompt("Ingresa grados celcius : "));
//declaracion de constantes
const k = 273.15;
const f1 = 9/5;
const f2 = 32;
//Lo celciu
document.write("<p style=\"font-size: 18x; color: green;\">La conversion de Grados celcius : " + c1 + " a Kelvin   ==>> " + (c1+k) + " Kelvin</p>")
//Lo farenjeit
document.write("<p style=\"font-size: 18x; color: blue;\">La conversion de Grados celcius : " + c1 + " a Fahrenheit  ==>> " + ((c1*f1) + f2) + " Fahrenheit</p>")


//----------------------------------------------------------------------------------------------------------------
//4. Pide dias 
//----------------------------------------------------------------------------------------------------------------
document.write("<p style=\"font-size:20px; border-bottom: solid 3px black; border-top: solid 9px blue;\">4. Dias a año semana dias. </p>")
//Pedida de gados celcius c1
var d1 = parseInt(prompt("Ingresa numero de dias : "));
//declaracion de constantes
const diasdelano = 365;
const diassemana = 7;
//La conversion a año sem dia
var agno = d1 / diasdelano;
agno = Math.floor(agno);
var resto = (d1 - agno * diasdelano);
var semana = resto / diassemana;
semana = Math.floor(semana);
var dias = (d1 - (agno * diasdelano) - (semana * diassemana));

document.write("<p style=\"font-size: 18x; color: green;\">Los " + d1 + "  dias, son : " + agno + " años, " + semana + " semanas y " + dias + " dias</p>")



//----------------------------------------------------------------------------------------------------------------
// 5.- Sumar 5 numeros y obtener su promedio
//----------------------------------------------------------------------------------------------------------------

document.write("<p style=\"font-size:20px; border-bottom: solid 3px black; border-top: solid 9px blue; border-top: solid 9px blue;\">5.- Sumar 5 numeros y promediar. </p>")
//Pedida de numbers N1
var n1 = parseInt(prompt("Ingresa un primer number mayor a 0 : "));
while (n1==0) {
    var n1 = parseInt(prompt("Ingresa un primer number mayor a 0  : "));
}

//Pedida de numbers N2
var n2 = parseInt(prompt("Ingresa un segundo number mayor a 0  : "));
while (n2==0) {
    var n2 = parseInt(prompt("Ingresa un segundo number mayor a 0  : "));
}

//Pedida de numbers N3
var n3 = parseInt(prompt("Ingresa un tercer number mayor a 0  : "));
while (n3==0) {
    var n3 = parseInt(prompt("Ingresa un tercer number mayor a 0  : "));
}

//Pedida de numbers N4
var n4 = parseInt(prompt("Ingresa un cuarto number mayor a 0  : "));
while (n4==0) {
    var n4 = parseInt(prompt("Ingresa un cuarto number mayor a 0  : "));
}

//Pedida de numbers N5
var n5 = parseInt(prompt("Ingresa un cuarto number mayor a 0  : "));
while (n5==0) {
    var n5 = parseInt(prompt("Ingresa un quinto number mayor a 0  : "));
}
//--Suma y promedio
var suma= n1 + n2 + n3 + n4 + n5;
var prom = suma / 5;


document.write("<p style=\"font-size: 18x; color: green;\">La suma de " + n1 + " + " + n2 + " + " + n3 + " + " + n4 + " + " + n5 + "</p>");
document.write("<p style=\"font-size: 18x; color: green;\">Es de  " + suma + "</p>");
document.write("<p style=\"font-size: 18x; color: green;\">Y su promedio es de " + prom + "</p>");
// Cierre del DIV
document.write("</div>")