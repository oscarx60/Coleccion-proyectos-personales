package cl.adl.sistemasolar.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import cl.adl.sistemasolar.Luna;
import cl.adl.sistemasolar.Planeta;

public class SistemaSolarTest {

	@Test
	void seLograCrearLuna() {

		// Luna Test
		ArrayList<Luna> lunaNueva = new ArrayList<Luna>();

		Luna lunaTest = new Luna();

		lunaTest.setNombre("Luna");
		lunaTest.setDiametro("384 mil km");
		lunaTest.setTiempoOrbita("30 dias");

		lunaNueva.add(lunaTest);

		assertNotNull(lunaNueva);
	}

	@Test
	void seVerificanPlanetasSinLunas() {

		Planeta planetasSinLunas = new Planeta();
		planetasSinLunas.setLuna(null);
		planetasSinLunas.setLuna2(null);
		assertEquals(null, planetasSinLunas.getLuna());
		assertEquals(null, planetasSinLunas.getLuna2());

	}

	@Test
	void seVerificanPlanetasConUnaLuna() {

		ArrayList<Luna> lunas1 = new ArrayList<Luna>();

		Luna luna1 = new Luna();
		luna1.setNombre("Luna");
		luna1.setDiametro("X km");
		luna1.setTiempoOrbita("Y dias");

		lunas1.add(luna1);

		Planeta planetaConUnaLuna = new Planeta();
		planetaConUnaLuna.setLuna(lunas1);
		planetaConUnaLuna.setLuna2(null);
		assertNotEquals(null, planetaConUnaLuna.getLuna());
		assertEquals(null, planetaConUnaLuna.getLuna2());

	}

	@Test
	void seVerificanPlanetasConDosLunas() {

		ArrayList<Luna> lunas1 = new ArrayList<Luna>();
		ArrayList<Luna> lunas2 = new ArrayList<Luna>();

		Luna luna1 = new Luna();
		luna1.setNombre("Luna");
		luna1.setDiametro("X km");
		luna1.setTiempoOrbita("Y dias");

		Luna luna2 = new Luna();
		luna2.setNombre("Luna");
		luna2.setDiametro("X km");
		luna2.setTiempoOrbita("Y dias");

		lunas1.add(luna1);
		lunas2.add(luna2);

		Planeta planetaConDosLunas = new Planeta();
		planetaConDosLunas.setLuna(lunas1);
		planetaConDosLunas.setLuna2(lunas2);
		assertNotEquals(null, planetaConDosLunas.getLuna());
		assertNotEquals(null, planetaConDosLunas.getLuna2());

	}

	@Test
	void verificarLuna() {

		ArrayList<Luna> lunas = new ArrayList<Luna>();

		Luna luna = new Luna();
		luna.setNombre("Luna");
		luna.setDiametro("X km");
		luna.setTiempoOrbita("Y dias");
		
		Luna lunaTest = new Luna();
		lunaTest.setNombre("Luna");

		lunas.add(luna);

		Planeta planetaTierra = new Planeta();
		planetaTierra.setLuna(lunas);
		planetaTierra.setLuna2(null);
		
		assertTrue(luna.getNombre() == (lunaTest.getNombre()));

	}

}
