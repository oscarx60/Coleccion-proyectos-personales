package soloPares2;

import java.util.Scanner;

public class SoloPares2 {

	public static void main(String[] args) {
		
		
		System.out.println("Ingrese la cantidad de n�meros pares necesarios:");
		Scanner sc= new Scanner(System.in);
		int numero= sc.nextInt();

		int i=0;
		int pares= 0;
		
		while (i< 2*numero) {
			i+=1;		
			if((i%2)==0)
{
	System.out.println(i);
}
}


}

}