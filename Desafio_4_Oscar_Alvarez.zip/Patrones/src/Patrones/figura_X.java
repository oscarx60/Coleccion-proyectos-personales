package Patrones;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class figura_X {

	public static void main(String[] args) 
	

			throws IOException{
		BufferedReader en= new BufferedReader(new InputStreamReader(System.in));

		int n;

		System.out.println("Digite el valor de n");
		n=Integer.parseInt(en.readLine());

		int y=(n-1);
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				if((i==j)||((i+j)==y)){
					System.out.print("*");
				}
				else{
					System.out.print(".");
				}

			}System.out.println();
		}
	}
}