/**
 * 
 */
package vista;

import java.util.List;
import java.util.Scanner;

import modelo.Cliente;
import servicio.ArchivoServicio;
import servicio.ClienteServicio;
import servicio.ExportadorCsv;
import servicio.ExportadorTxt;
import utilidades.Utilidad;

/**
 * @author Oscar Alvarez
 *
 */
public class Menu {

	//_________Atributos__________
	ClienteServicio clienteServicio = new ClienteServicio();
	ArchivoServicio archivoServicio = new ArchivoServicio();
	ExportadorCsv exportadorCsv = new ExportadorCsv();
	ExportadorTxt exportarTxt = new ExportadorTxt();


	//________Para exportar el archivo____
	String fileName = "Clientes";

	//________Para importar el archivo____
	String fileName1 = "DBClientes.csv";

	//_______Para recibir valores desde teclado____
	Scanner scanner = new Scanner(System.in);

	//___________M�todo____________
	public void iniciarMenu() {

		boolean continuar=false;
		//_______Navegaci�n______
		do {
			System.out.println("1. Listar Clientes");
			System.out.println("2. Agregar Cliente");
			System.out.println("3. Editar Cliente");
			System.out.println("4. Cargar Datos");
			System.out.println("5. Exportar Datos");
			System.out.println("6. Salir");
			System.out.println("Ingrese una opci�n:");
			String opcion = scanner.nextLine();
			switch(opcion) {
			case "1":
				listarCliente();
				break;
			case "2":
				agregarCliente();
				break;
			case "3":
				editarCliente();
				break;
			case "4":
				importarDatos();
				break;
			case "5":
				exportarDatos();
				break;
			case "6":
				terminarPrograma();
			default:
				System.out.println("Opci�n no v�lida");
			}


		} while (!continuar);
	}

	private void listarCliente() {
		clienteServicio.listarClientes();
	}

	private void agregarCliente() {
		System.out.println("Ingrese run del cliente:");
		String run = scanner.nextLine();
		System.out.println("Ingrese nombre del cliente:");
		String nombre = scanner.nextLine();
		System.out.println("Ingrese apellido del cliente:");
		String apellido = scanner.nextLine();
		System.out.println("Ingrese a�os como cliente:");
		String anios = scanner.nextLine();
		clienteServicio.agregarCliente(run, nombre, apellido, anios);
	}

	private void editarCliente() {
		List<Cliente> listaClientes = clienteServicio.getListaClientes();
		System.out.println("Ingrese run del cliente a editar:");
		String editar = scanner.nextLine();
		int confirmar=0;
		if (listaClientes.size()==0) {
			System.out.println("La lista se encuentra actualmente vac�a, por favor agregue clientes a la lista\n");
		}
		else {
			for (Cliente cliente : listaClientes) {
				if (cliente.getRunCliente().equals(editar)) {
					String run = cliente.getRunCliente();
					String nombre = cliente.getNombreCliente();
					String apellido = cliente.getApellidoCliente();
					String anios = cliente.getAniosCliente();

					clienteServicio.editarCliente(run, nombre, apellido, anios, cliente);
					confirmar++;
				}
			}if(confirmar==0) {
				System.out.println("No se encontr� el rut del cliente");
			}
		}
	}

	private void importarDatos() {

		System.out.println("Ingrese la ruta de su archivo DBClientes.csv a importar");

		List<Cliente> listaClientes = clienteServicio.getListaClientes();
		List<Cliente> listaImportar = archivoServicio.cargarDatos(fileName1);

		if(listaImportar.size()!=0) {

			listaClientes.addAll(listaImportar);
			System.out.println("Los datos han sido agregados a la lista correctamente");
		}
		
		Utilidad.EsperaYLimpieza();
	}

	private void exportarDatos() {

		System.out.println("Seleccione formato a exportar");
		System.out.println("-----------------------------------");
		System.out.println("1. Exportar CSV");
		System.out.println("2. Exportar TXT");
		List<Cliente> listaClientes = clienteServicio.getListaClientes();
		String opcion = scanner.nextLine();
		switch (opcion) {

		case "1":
			exportadorCsv.exportar(fileName + ".csv", listaClientes);
			break;

		case "2":
			exportarTxt.exportar(fileName + ".txt", listaClientes);
			break;

		default:
			System.out.println("Opci�n incorrecta, vuelva a ingresar su opci�n");

		}

	}

	private void terminarPrograma() {
		System.out.println("-----------------------");
		System.out.println("Usted eligi�: Salir\n");

		Utilidad.EsperaYLimpieza();

		System.out.println("Abandonando el Menu.......");

		Utilidad.EsperaYLimpieza();

		System.out.println("Acaba de salir del Sistema, hasta pronto");
		System.out.println("");
		
		Utilidad.EsperaYLimpieza();

		System.exit(0);

	}
}
