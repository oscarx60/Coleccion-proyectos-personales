/**
 * 
 */
package servicio;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;

/**
 * @author Oscar Alvarez
 *
 */
public class ExportadorTxt extends Exportador {
	Scanner scanner = new Scanner(System.in);
	@Override
	public void exportar(String fileName, List<Cliente> listaClientes) {


		if(listaClientes.size()==0) {
			System.out.println("La lista se encuentra vac�a, favor ingrese un cliente a la lista");

		}else {
			String separador = ",";
			System.out.println("Ingrese la ruta donde se exportar� el archivo .Txt");
			String rutaArchivo = scanner.nextLine();
			String elArchivo = rutaArchivo + "/" + fileName;

			File crearArchivo = new File(elArchivo);

			try {
				
				if(crearArchivo.exists()) {
					crearArchivo.delete();
					System.out.println("El archivo se sobreescribi�");

				}
				FileWriter writer = new FileWriter(crearArchivo);
				BufferedWriter bufferedW = new BufferedWriter(writer);

				for(Cliente cliente : listaClientes) {
					bufferedW.append(cliente.getRunCliente()).append(separador).append(cliente.getNombreCliente()).append(separador)
					.append(cliente.getApellidoCliente()).append(separador).append(cliente.getAniosCliente());

					bufferedW.newLine();
				}
				bufferedW.close();
				System.out.println("El archivo se ha creado correctamente");
			}catch (Exception error) {
				System.out.println("Error al crear el archivo" + error.getMessage());


			}
		}
	}


}


