package Ejercicios;

import java.util.Arrays;
import java.util.ArrayList;
 
public class SmartWatch {
 
    static ArrayList<Integer> clearSteps(int[] steps) {
 
        ArrayList<Integer> filteredSteps = new ArrayList<Integer>();
 
        for(int i = 0; i < steps.length; i++) {
            if(steps[i] < 200 || steps[i] > 100000) {
                continue;
            }
 
            else {
                filteredSteps.add(steps[i]);
            }
        }
 
        return filteredSteps;
    }
 
    
    static float calculateAverage(ArrayList<Integer> filteredSteps) {
 
        float stepsAverage = 0;
        long stepsSum = 0;
 
        for(int i = 0; i < filteredSteps.size(); i++) {
            stepsSum += filteredSteps.get(i);
        }
 
        stepsAverage = stepsSum / filteredSteps.size();
 
        return stepsAverage;
    }
 
    public static void main(String[] args) {
        int[] steps = new int[args.length];
 
        for(int i = 0; i < args.length; i++) {
            steps[i] = Integer.parseInt(args[i]);
        } 
 
        System.out.print("El promedio de pasos totales es: ");
        System.out.println(calculateAverage(clearSteps(steps)));
    }
}