package cl.adl.sistemasolar.interfaz.impl;

import java.util.ArrayList;

import cl.adl.sistemasolar.Luna;
import cl.adl.sistemasolar.interfaz.ILuna;

public class ILunaImpl implements ILuna {

	public ArrayList<Luna>construirLuna(String nombre, String diametro, String tiempoOrbita) {
		
		ArrayList<Luna> lunaNueva = new ArrayList<Luna>();
		Luna luna = new Luna();
		
		if(nombre != null && diametro != null && tiempoOrbita != null) {
		luna.setNombre(nombre);
		luna.setDiametro(diametro);
		luna.setTiempoOrbita(tiempoOrbita);
		} else {
			luna.setNombre(null);
			luna.setDiametro(null);
			luna.setTiempoOrbita(null);
		}
		
		lunaNueva.add(luna);
		
		return lunaNueva;
		
	}

}
