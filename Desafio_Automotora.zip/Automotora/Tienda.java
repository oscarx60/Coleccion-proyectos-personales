/**
 * 
 */
package Automotora;

/**
 * @author Oscar Alvarez C. 
 *
 */
public class Tienda {
	
	private Vendedor vendedor;
	private Vehiculo vehiculo;
	private int stock;
	
	/**
	 * @param vendedor
	 * @param vehiculo
	 * @param stock
	 */
	public Tienda(Vendedor vendedor, Vehiculo vehiculo, int stock) {
		super();
		this.vendedor = vendedor;
		this.vehiculo = vehiculo;
		this.stock = stock;
	}
	
	public Tienda() {
		
	}
	/**
	 * @return the vendedor
	 */
	public Vendedor getVendedor() {
		return vendedor;
	}
	/**
	 * @param vendedor the vendedor to set
	 */
	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}
	/**
	 * @return the vehiculo
	 */
	public Vehiculo getVehiculo() {
		return vehiculo;
	}
	/**
	 * @param vehiculo the vehiculo to set
	 */
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}
	/**
	 * @return the stock
	 */
	public int getStock() {
		return stock;
	}
	/**
	 * @param stock the stock to set
	 */
	public void setStock(int stock) {
		this.stock = stock;
	}
	
	public String existeStock() {
		return String.valueOf(getStock());
	}


}
