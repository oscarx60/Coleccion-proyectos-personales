validar();

function validar() {
    
    var limite = parseInt(prompt("Ingrese numero del 1 al 20"));

    if (limite > 1 && limite < 20) {
        
        for(var i = 1; i<=limite; i++) {

              let multiplicacion = (i, limite) => console.log(i + " x " + limite + " = " + i*limite);

              multiplicacion(i, limite);
        }

        for(var j=1; j<=limite; j++){
            var miFact = factorial(j);
            console.log("El factorial de " + j + " = " + miFact);
        }



    } else {

        alert("Numero fuera de rango");
    }

}

//El uso de resursividad esta aprobado por Don Rodrigo Silva, profesor de Fullstack Java

function factorial(contador){
   
    if (contador > 1) {

        return contador * factorial(contador - 1);  // n! = n*(n-1)!

    } else {
        return contador;
    }

}




