/**
 * 
 */
package Automotora;

/**
 * @author Oscar Alvarez C. 
 *
 */
public class Vendedor extends Persona {
	
	private String Direccion;

	/**
	 * @param rut
	 * @param nombre
	 * @param edad
	 * @param direccion
	 */
	public Vendedor(String rut, String nombre, int edad, String direccion) {
		super(rut, nombre, edad);
		Direccion = direccion;
	}
	
	public Vendedor() {
		
	}

	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return Direccion;
	}

	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		Direccion = direccion;
	}
	
	
	
	

}
