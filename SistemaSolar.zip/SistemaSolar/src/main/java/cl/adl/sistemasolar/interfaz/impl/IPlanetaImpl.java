package cl.adl.sistemasolar.interfaz.impl;

import java.util.ArrayList;

import cl.adl.sistemasolar.Luna;
import cl.adl.sistemasolar.Planeta;
import cl.adl.sistemasolar.interfaz.IPlaneta;

public class IPlanetaImpl implements IPlaneta {

	public Planeta construirPlaneta(String nombre, String tama�o, String distanciaAlSol,
			String distanciaALuna, ArrayList<Luna> luna, ArrayList<Luna> luna2) {
		
		Planeta planeta = new Planeta();
		
		planeta.setNombre(nombre);
		planeta.setTama�o(tama�o);
		planeta.setDistanciaAlSol(distanciaAlSol);
		planeta.setDistanciaALuna(distanciaALuna);
		
		if(luna == null && luna2 == null) {
		planeta.setLuna(null);
		planeta.setLuna2(null);
		} else {
			planeta.setLuna(luna);
			planeta.setLuna2(luna2);
		}
		
		return planeta;
		
	}
	
}
