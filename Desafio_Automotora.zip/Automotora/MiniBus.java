/**
 * 
 */
package Automotora;

/**
 * @author Oscar Alvarez C. 
 *
 */
public class MiniBus extends Bus{
		
	private String tipoViaje;
	
	/**
	 * @param color
	 * @param patente
	 * @param cantidadDeAsientos
	 * @param tipoViaje
	 */
	public MiniBus(String color, String patente, int cantidadDeAsientos, String tipoViaje) {
		super(color, patente, cantidadDeAsientos);
		this.tipoViaje = tipoViaje;
	}
	
	public MiniBus() {
		
	}

	

	/**
	 * @return the tipoViaje
	 */
	public String getTipoViaje() {
		return tipoViaje;
	}

	/**
	 * @param tipoViaje the tipoViaje to set
	 */
	public void setTipoViaje(String tipoViaje) {
		this.tipoViaje = tipoViaje;
	}
	
	public void imprimeBus() {
		
		System.out.println(tipoViaje);
		System.out.println(color);
		System.out.println(patente);
		System.out.println(cantidadDeAsientos);
		
	}

}
