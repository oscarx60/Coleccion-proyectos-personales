package servicio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.Cliente;
import utilidades.Utilidad;

public class ArchivoServicio extends Exportador {

	Scanner ingreso = new Scanner(System.in);

	public List<Cliente> cargarDatos(String fileName) {

		List<Cliente> listaClientes = new ArrayList<Cliente>();

		String ruta = ingreso.nextLine();

		String ubicacion = ruta + "/" + fileName;

		File crearArchivo = new File(ubicacion);

		try {
			if (!crearArchivo.isFile()) {
				System.out.println("El arhivo que est� intentando abrir no existe, o no est� creado");

			}
			else {
				FileReader lectorArchivo = new FileReader(crearArchivo);
				BufferedReader lectorbkn = new BufferedReader(lectorArchivo);

				String datosArchivo = lectorbkn.readLine();

				while (datosArchivo!=null) {
					Cliente cliente = new Cliente();
					String[] datos = datosArchivo.split(",",4);

					cliente.setRunCliente(datos[0]);
					cliente.setNombreCliente(datos[1]);
					cliente.setApellidoCliente(datos[2]);
					cliente.setAniosCliente(datos[3]);

					listaClientes.add(cliente);
					datosArchivo = lectorbkn.readLine();

				}
				lectorbkn.close();

				System.out.println("Los datos han sido agregados a lista correctamente");

				Utilidad.EsperaYLimpieza();

				System.out.println("Favor confirmar nuevos datos en Listar Clientes o Exportar Datos");
			}
		}catch(Exception e) {
			System.out.println("Error: Se ha generado el siguiente error al intentar leer el archivo" + e.getMessage());		
		}
		return listaClientes;
	}





	@Override
	public void exportar(String fileName, List<Cliente> listaClientes) {

		Exportador exportador = new ExportadorCsv();
		Exportador exportador2 = new ExportadorTxt();
		exportador.exportar(fileName, listaClientes);
		exportador2.exportar(fileName, listaClientes);


	}

}
