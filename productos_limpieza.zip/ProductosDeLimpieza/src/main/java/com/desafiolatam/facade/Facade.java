package com.desafiolatam.facade;

import java.sql.SQLException;
import java.util.List;

import com.desafiolatam.dao.CategoriaDAO;
import com.desafiolatam.dao.ProductoDAO;
import com.desafiolatam.dto.CategoriaDTO;
import com.desafiolatam.dto.ProductoDTO;

public class Facade {

	public int insertarProducto(ProductoDTO dto) throws SQLException, ClassNotFoundException {

		ProductoDAO insertarDAO = new ProductoDAO();
		return insertarDAO.insertarProducto(dto);
	}

	public List<CategoriaDTO> obtieneCategorias() throws SQLException, ClassNotFoundException {

		CategoriaDAO daoCategoria = new CategoriaDAO();
		return daoCategoria.obtieneCategoria();

	}


	public List<ProductoDTO> obtieneProductos() throws SQLException, ClassNotFoundException{
		ProductoDAO obtenerDAO = new ProductoDAO();
		return obtenerDAO.obtieneProductos();

	}


	public int borraProductos(Integer idUsuario) throws SQLException, ClassNotFoundException{
		ProductoDAO borrarDAO = new ProductoDAO();
		return borrarDAO.eliminaProductos(idUsuario);
	}


	public ProductoDTO encontrarProducto(Integer idUsuario) throws SQLException, ClassNotFoundException {
		ProductoDAO encontrarDAO = new ProductoDAO();
		return encontrarDAO.encuentraProductos(idUsuario);


	}

	public void editarProducto(ProductoDTO dto, Integer idProducto) throws SQLException, ClassNotFoundException{
		ProductoDAO editarDAO = new ProductoDAO();
		editarDAO.edicionProducto(dto, idProducto);

	}



}
