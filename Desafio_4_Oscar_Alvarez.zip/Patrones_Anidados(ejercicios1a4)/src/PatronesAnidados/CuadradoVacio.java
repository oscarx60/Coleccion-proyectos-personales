package PatronesAnidados;

import java.util.Scanner;

public class CuadradoVacio {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		if (n==1) 
			System.out.print("*");
//primera linea para n>2			
		else {
		for(int i = 1; i <=n; i++) {
			System.out.print("*");
		}System.out.printf("\n");
//en el medio
		for(int i = 1; i <=n-2; i++) {
			System.out.print("*");
			for (int j=1; j<=n-2; j++) {
				System.out.print(" ");
			}
				System.out.println("*");
//fila final
	}for (int i=1; i<=n; i++) {
		System.out.print("*");
		}
	System.out.println("\n");
	}}}