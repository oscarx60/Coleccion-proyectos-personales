package PatronesAnidados;
import java.util.Scanner;
public class Z {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		if (n==1) 
			System.out.print("*");
		//primera linea para n>2
		else {
			for(int i = 1; i <=n; i++) {
				System.out.print("*");
			}System.out.printf("\n");
			//en el medio
			for (int j=1; j<n-1; j++) {//j<n-1 me indica la cantidad de filas para abajo en el medio
				System.out.println(j);
				
				}
			
	//lo que viene es la l�nea final		
		}for (int i=1; i<=n; i++) {
			System.out.print("*");
		}
	}
}