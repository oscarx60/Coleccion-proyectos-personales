/**
 * 
 */
package Automotora;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author Oscar Alvarez C. 
 *
 */
public class LibroVenta {

	private String nombreVenta;
	private String fechaVenta;

	/**
	 * @param nombreVenta
	 * @param fechaVenta
	 */
	public LibroVenta(String nombreVenta, String fechaVenta) { // Constructor lleno
		super();
		this.nombreVenta = nombreVenta;
		this.fechaVenta = fechaVenta;
	}

	public LibroVenta() { // Constructor vac�o

	}

	/**
	 * @return the nombreVenta
	 */
	public String getNombreVenta() {
		return nombreVenta;
	}

	/**
	 * @param nombreVenta the nombreVenta to set
	 */
	public void setNombreVenta(String nombreVenta) {
		this.nombreVenta = nombreVenta;
	}

	/**
	 * @return the fechaVenta
	 */
	public String getFechaVenta() {
		return fechaVenta;
	}

	/**
	 * @param fechaVenta the fechaVenta to set
	 */
	public void setFechaVenta(String fechaVenta) {
		this.fechaVenta = fechaVenta;
	}

	public void guardarVenta(Cliente cliente, Vehiculo vehiculo) {
		File miCarpeta = new File("src/ficheros");
		File miArchivo = new File(miCarpeta+"/"+nombreVenta+".txt");

		if(!miCarpeta.exists()) {
			
		
		
		try {

			if(miCarpeta.mkdir()){ // Crea el directorio y comprueba que se cre� correctamente

				if(!miArchivo.exists()) { // Si mi archivo no existe....


					miArchivo.createNewFile(); // Crea el archivo y comprueba que se cre� correctamente
					
				FileWriter miEscritor = new FileWriter(miArchivo);
				BufferedWriter miBuffer = new BufferedWriter(miEscritor);
				
				String dias = fechaVenta.substring(0, 2); // Empieza en el 0, pero frena en el 2
				
				String mes = fechaVenta.substring(2, 4);
				
				String anho = fechaVenta.substring(4, 8);
				
				int diasNum = Integer.parseInt(dias);
				
				int mesNum = Integer.parseInt(mes);
				
				int anhoNum = Integer.parseInt(anho);
				
				miBuffer.write(vehiculo.patente);
				
				miBuffer.newLine();
				
				miBuffer.write(String.valueOf(cliente.edad));
				
				miBuffer.newLine();
				
				miBuffer.write(nombreVenta);
				
				miBuffer.newLine();
				
				miBuffer.write(diasNum + "/");
				
				miBuffer.write(mesNum + "/");
				
				miBuffer.write(anhoNum + " ");
				
				miBuffer.close();
				
				System.out.println("Fichero fue creado exitosamente");
					
				} else {
					
					System.out.println("Fichero ya existe");
				}

			} 

		}
		
		catch (IOException e) {
			
				System.out.println("Ocurri� el siguiente error" + e);
			
		}
		
	}else {
		System.out.println("El directorio ya existe");
	}
		
}
}
