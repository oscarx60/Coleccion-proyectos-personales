/**
 * 
 */
package ReciclaJeans;

import java.util.List;

/**
 * @author Oscar Alvarez C. 
 *
 */
public abstract class Exportador {

	public void exportar(String nombreArchivo, String ruta, List<Producto>listaProductos) {


	}

}