package MirandoAlPasado;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Desafio_Mirando_Al_Pasado {

	public static void main(String[] args) {

		//___________Ejercicio1_________________
		ArrayList<String> marcas = new ArrayList(); // Listado de marcas
		marcas.add("Lan");
		marcas.add("Ladeco");
		marcas.add("Salo");
		marcas.add("Yupi");
		marcas.add("Caricia");
		marcas.add("Ekono");
		marcas.add("Pluma");
		marcas.add("Oba Oba");
		marcas.add("Inkat");
		marcas.add("Negrita");

		System.out.println("Marcas del pasado: " + marcas + "\n");

		marcas.add("Blokbaster");// Posicion 10
		marcas.add("Carrefour");//  Posicion 11
		marcas.add("Jetix");

		System.out.println("Listado de marcas del pasado actualizadas: " + marcas  +"\n");

		marcas.set(10, "BlockBuster"); // Agregamos un reemplazo en la posicion de BlokBaster

		System.out.println("Listado actualizado con correccion a palabra BlokBaster: " + marcas + "\n");

		if (marcas.remove("Carrefour")) { // Removemos Carrefour del listado anterior
			System.out.println("Listado de marcas sin Carrefour: " + marcas + "\n");
		}

		else {
			System.out.println("No se pudo remover"); // Lanzar�a este mensaje en pantalla en caso de que 
		}

		ArrayList<String> posiblesMarcas = new ArrayList(); // Agregamos un nuevo ArrayList con posibles marcas para agregar a marcas
		posiblesMarcas.add("Delta");
		posiblesMarcas.add("Las Brisas");
		posiblesMarcas.add("Banco Nacional");

		marcas.addAll(posiblesMarcas);


		System.out.println("Agregamos otras marcas de empresas al listado original: " + marcas + "\n");
		System.out.println("El tama�o total de la lista actualizada es de: " + marcas.size() + "\n");

		//____________Ejercicio2_______________
		Set<String> invitados = new TreeSet<>(); // Hacemos un nuevo listado de invitados
		invitados.add("Daniel");
		invitados.add("Paola");
		invitados.add("Facundo");
		invitados.add("Pedro");
		invitados.add("Jacinta");
		invitados.add("Florencia");
		invitados.add("Juan Pablo");

		Set<String> posiblesInvitados = new TreeSet<>(); // Agregamos nuevos invitados con TREESET, para agregar adem�s un orden alfab�tico
		posiblesInvitados.add("Jorge");
		posiblesInvitados.add("Francisco");
		posiblesInvitados.add("Marcos");

		invitados.addAll(posiblesInvitados); // Con m�todo addAll agregamos los nuevos invitados

		System.out.println("Listado de invitados: " + invitados + "\n");

		invitados.remove("Jorge");// Removemos de nuestra lista de invitados a Jorge

		System.out.println("La lista actualizada de invitados es la siguiente: " + invitados + "\n");


		//__________________Ejercicio3__________________

		Map<String, Integer> golosinas = new TreeMap<>(); // Generamos un nuevo listado con TreeMap
		golosinas.put("Chocman", 100);
		golosinas.put("Trulul�", 100);
		golosinas.put("Centella", 100);
		golosinas.put("Kilate", 50);
		golosinas.put("Miti-Miti", 30);	
		golosinas.put("Traga Traga", 150);	
		golosinas.put("Tablet�n", 5);

		golosinas.entrySet().stream().filter(
				precio -> precio.getValue()<100).forEach(System.out::println);
		System.out.println();

		//______________Ejercicio 4_______________

		Queue<String> juegos = new LinkedList<>(); // Generamos una nueva lista de juegos
		juegos.add("Tombo");
		juegos.add("Congelado");
		juegos.add("Quemaditas");
		juegos.add("Cachip�n");
		juegos.add("Pillarse");

		System.out.println("La lista de juegos es: " + juegos);

		System.out.println("El tama�o de la lista de juegos es: " + juegos.size());


	}

}
