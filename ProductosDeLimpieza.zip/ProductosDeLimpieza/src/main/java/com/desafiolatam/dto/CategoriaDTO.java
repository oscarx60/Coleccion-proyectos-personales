package com.desafiolatam.dto;

public class CategoriaDTO {

	private Integer id_categoria;
	private String nombre_categoria;


	//_________	GETTERS Y SETTERS___________
	/**
	 * @return the id_categoria
	 */
	public Integer getId_categoria() {
		return id_categoria;
	}
	/**
	 * @param id_categoria the id_categoria to set
	 */
	public void setId_categoria(Integer id_categoria) {
		this.id_categoria = id_categoria;
	}
	/**
	 * @return the nombre_categoria
	 */
	public String getNombre_categoria() {
		return nombre_categoria;
	}
	/**
	 * @param nombre_categoria the nombre_categoria to set
	 */
	public void setNombre_categoria(String nombre_categoria) {
		this.nombre_categoria = nombre_categoria;
	}


	//________TO STRING________
	@Override
	public String toString() {
		return "CategoriaDTO [id_categoria=" + id_categoria + ", nombre_categoria=" + nombre_categoria + "]";
	}




}
