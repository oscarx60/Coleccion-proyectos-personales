CREATE DATABASE productos_limpieza;

--TABLA CATEGORIA 
CREATE TABLE categoria(
id_categoria int primary key,
nombre_categoria varchar(50)
);

-- TABLA PRODUCTO
CREATE TABLE producto(
id_producto serial primary key,
nombre_producto varchar(75),
precio_producto int,
descripcion_producto varchar(200),
id_categoria int,
foreign key (id_categoria) references categoria(id_categoria)
);

INSERT INTO categoria(id_categoria, nombre_categoria)
VALUES (1, 'Detergente li�quido');

INSERT INTO categoria(id_categoria, nombre_categoria)
VALUES (2, 'Detergente en polvo');


INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Omo', 3500, 'Quita manchas', 1);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Ariel', 4400, 'Quita manchas', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Popeye', 4400, 'Quita manchas', 2);


INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Drive', 4400, 'Quita manchas', 2);


INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Cloro', 4400, 'Desinfectante', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Jab�n l�quido', 4400, 'Limpiador', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Escoba', 4400, 'Limpiador', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Cera', 4400, 'Saca Brillo', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Lustra Muebles', 4400, 'Saca Brillo', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Suavizante de ropa', 4400, 'Ablandador', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Jab�n', 4400, 'Desinfectante', 2);

INSERT INTO producto(nombre_producto, precio_producto, descripcion_producto, id_categoria)
VALUES ('Virutilla', 4400, 'Limpiador', 2);


select * from categoria;
select * from producto;
