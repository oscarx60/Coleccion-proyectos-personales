
var cuadradoVacio = document.getElementById("caja");
function agregarColor (color) {
    cuadradoVacio.style.backgroundColor = color;
}
document.getElementById("btn-1").addEventListener("click", function(){
    var boton = document.getElementById("btn-1");
    var color = boton.style.backgroundColor;
    agregarColor(color);
});

document.getElementById("btn-2").addEventListener("click", function(){
    var boton = document.getElementById("btn-2");
    var color = boton.style.backgroundColor;
    agregarColor(color);
});

document.getElementById("btn-3").addEventListener("click", function(){
    var boton = document.getElementById("btn-3");
    var color = boton.style.backgroundColor;
    agregarColor(color);
});

document.getElementById("btn-4").addEventListener("click", function(){
    var boton = document.getElementById("btn-4");
    var color = boton.style.backgroundColor;
    agregarColor(color);
});


document.getElementById("btn-5").addEventListener("click", function(){
    var boton = document.getElementById("btn-5");
    var color = boton.style.backgroundColor;
    agregarColor(color);
});


document.getElementById("btn-6").addEventListener("click", function(){
    var boton = document.getElementById("btn-6");
    var color = boton.style.backgroundColor;
    agregarColor(color);
});

