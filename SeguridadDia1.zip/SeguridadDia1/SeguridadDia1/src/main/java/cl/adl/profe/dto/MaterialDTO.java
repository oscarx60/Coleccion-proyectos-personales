package cl.adl.profe.dto;

public class MaterialDTO {
	
	private String clave;
	private String valor;
	private String bodega;
	private String ingreso;
	
		
	
	public MaterialDTO() {
		super();
		
	}
	public MaterialDTO(String clave, String valor) {
		super();
		this.clave = clave;
		this.valor = valor;
		
		
	}
	/**
	 * @return the clave
	 */
	
	
	public String getClave() {
		return clave;
	}
	/**
	 * @return the bodega
	 */
	public String getBodega() {
		return bodega;
	}
	/**
	 * @param bodega the bodega to set
	 */
	public void setBodega(String bodega) {
		this.bodega = bodega;
	}
	/**
	 * @return the ingreso
	 */
	public String getIngreso() {
		return ingreso;
	}
	/**
	 * @param ingreso the ingreso to set
	 */
	public void setIngreso(String ingreso) {
		this.ingreso = ingreso;
	}
	/**
	 * @param clave the clave to set
	 */
	public void setClave(String clave) {
		this.clave = clave;
	}
	/**
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}
	/**
	 * @param valor the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}
	
	@Override
	public String toString() {
		return "MaterialDTO [clave=" + clave + ", valor=" + valor + "]";
	}
	
	
	

}
