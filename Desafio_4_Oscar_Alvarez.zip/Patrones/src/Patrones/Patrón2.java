package Patrones;

import java.util.Scanner;

public class Patr�n2 {

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.printf("Ingresa un n�mero: ");
			int n = sc.nextInt();
			int i;
			for(i=0;i<n;i++) {
					if(i%4==0)	System.out.printf("1");
			else if (i%4==1)	System.out.printf("2");
			else if (i%4==2)	System.out.printf("3");
			else if (i%4==3)	System.out.printf("4");
			}
			System.out.printf("\n");
			}
		}
