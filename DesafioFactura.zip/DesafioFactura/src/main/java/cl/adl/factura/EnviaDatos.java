package cl.adl.factura;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EnviaDatos
 */
@WebServlet("/EnviaDatos")
public class EnviaDatos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnviaDatos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int valorValvulas = (int) request.getAttribute("Valvulas") * 120000;
		int valorTurbo = (int) request.getAttribute("Turbo") * 1000000;
		int valorFrenos = (int) request.getAttribute("Frenos") * 850000;
		int valorRefrigeracion = (int) request.getAttribute("Cooling") * 2300000;
		int valorPlumillas = (int) request.getAttribute("Plumillas") * 15000;
		
		int cantidadValvulas = (int) request.getAttribute("Valvulas");
		int cantidadTurbo = (int) request.getAttribute("Turbo");
		int cantidadFrenos = (int) request.getAttribute("Frenos");
		int cantidadRefrigeracion = (int) request.getAttribute("Cooling");
		int cantidadPlumillas = (int) request.getAttribute("Plumillas");
		
		
		request.setAttribute("TotalV", valorValvulas);
		request.setAttribute("TotalR", valorTurbo);
		request.setAttribute("TotalF", valorFrenos);
		request.setAttribute("TotalC", valorRefrigeracion);
		request.setAttribute("TotalP", valorPlumillas);
		
		request.setAttribute("NombreF", request.getAttribute("Nombre"));
		request.setAttribute("EmpresaF", request.getAttribute("Empresa"));
		request.setAttribute("RutF", request.getAttribute("Rut"));
		request.setAttribute("DireccionF", request.getAttribute("Direccion"));
		request.setAttribute("CiudadF", request.getAttribute("Ciudad"));
		request.setAttribute("PaisF", request.getAttribute("Pais"));
		
		RequestDispatcher rd = request.getRequestDispatcher("compraUsuario.jsp");
		rd.forward(request, response);
		doGet(request, response);
	}

}
