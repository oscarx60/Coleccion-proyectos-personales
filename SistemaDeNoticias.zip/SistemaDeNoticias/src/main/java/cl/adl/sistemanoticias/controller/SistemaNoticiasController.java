package cl.adl.sistemanoticias.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cl.adl.sistemanoticias.SistemaDeNoticiasApplication;

@Controller
@RequestMapping(value = "/noticias", method = RequestMethod.GET)
public class SistemaNoticiasController {
	
	private static final Logger logger = LoggerFactory.getLogger(SistemaDeNoticiasApplication.class);

	@RequestMapping(value = "/actualidad", method = RequestMethod.GET)
	public String noticias(ModelMap map) {

		ArrayList<String> datosDeArchivo = new ArrayList<String>();
		
		List<String> elementos = new ArrayList<String>();
		String[] noticia = null;

		try {
			String file = "src/main/resources/noticias.txt";

			BufferedReader reader = new BufferedReader(new FileReader(file));
			String lineaActual = reader.readLine();

			while (lineaActual != null) {
				datosDeArchivo.add(lineaActual);
				lineaActual = reader.readLine();
			}
			logger.info("Noticia lista para ser desplegada!");
			reader.close();
		} catch (IOException e) {
			logger.trace("Error al encontrar el archivo!", e);
			logger.error("Error, no es posible leer el archivo");
			e.printStackTrace();
		}
		
		for(int i = 0; i < datosDeArchivo.size(); i++) {
			noticia = datosDeArchivo.get(i).split("@@");
			elementos.addAll(Arrays.asList(noticia));
			i++;
		}
		
		map.put("listaElementos", elementos);
		return "paginaprueba";
	}
}
