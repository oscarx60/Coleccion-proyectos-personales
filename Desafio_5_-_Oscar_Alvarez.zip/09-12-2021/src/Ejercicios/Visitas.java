package Ejercicios;

import java.util.ArrayList;

public class Visitas {
	
    static float promedio(Long[] visitas) {
        float promedioVisitas = 0;
        long sumaVisitas = 0;
 
        for(int i = 0; i < visitas.length; i++) {
            sumaVisitas += visitas[i];
        }
 
        promedioVisitas = sumaVisitas / visitas.length;
 
        return promedioVisitas;
    }
    public static void main(String[] args) {
        Long[] visitas = new Long[args.length];
 
        for(int i = 0; i < args.length; i++) {
            visitas[i] = Long.parseLong(args[i]);
        }
 
        System.out.println("Para la entrada anterior, el resultado es " + promedio(visitas));
    }
}