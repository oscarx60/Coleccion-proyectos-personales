/**
 * 
 */
package ReciclaJeans;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;

/**
 * @author Oscar Alvarez C.
 *
 */
public class ExportadorTxt extends Exportador {

	@Override 
	public void exportar(String nombreArchivo, String ruta, List<Producto> listaProductos) {



		if(listaProductos.size()==0) { // Confirmo si la lista esta vacia

			System.out.println("La lista actualmente esta vac�a");
		}else {

			String archivo = ruta + "/" + nombreArchivo + ".txt";

			File crearCarpeta = new File(ruta);
			File crearArchivo = new File(archivo);

			try {



				if(!crearCarpeta.exists()) {
					crearCarpeta.mkdir();
				}

				if(crearArchivo.exists()) {
					crearArchivo.delete(); // Confirma si mi archivo ya existe, si ya existe, borrar el archivo existente
				}
				FileWriter escritor = new FileWriter(crearArchivo);
				BufferedWriter escritorb = new BufferedWriter(escritor);

				for (Producto producto : listaProductos) {
					escritorb.write("Articulo: ");
					escritorb.write(producto.getArticulo());
					escritorb.write(" Codigo: ");
					escritorb.write(producto.getCodigo());
					escritorb.write(" Color: " );
					escritorb.write(producto.getColor());
					escritorb.write(" Descripcion: ");
					escritorb.write(producto.getDescripcion());
					escritorb.write(" Marca: ");
					escritorb.write(producto.getMarca());
					escritorb.write(" Precio: ");
					escritorb.write(producto.getPrecio());
					escritorb.write(" Talla: ");
					escritorb.write(producto.getTalla());
					escritorb.newLine();

				}
				escritorb.close();
				System.out.println("Datos correctamente exportados a .txt");
			}catch(Exception Error) {
				System.out.println("Error, archivo no se pudo crear, se encontr� el siguiente problema" + Error.getMessage());

			}
		}

		Utilidad.EsperaYLimpieza();
	}
}	





