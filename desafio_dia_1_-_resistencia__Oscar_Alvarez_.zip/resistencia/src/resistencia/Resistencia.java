package resistencia;

import java.util.Scanner;

public class Resistencia {

	public static void main(String[] args) {

		float numero_r1;
		float numero_r2;
		float numero_r3;

		System.out.printf("Ingrese resistencia 1: ");
		Scanner leer = new Scanner(System.in); 
		numero_r1=leer.nextInt();

		System.out.printf("Ingrese resistencia 2: ");
		Scanner leer1 = new Scanner(System.in); 
		numero_r2=leer.nextInt();

		System.out.printf("Ingrese resistencia 3: ");
		Scanner leer2 = new Scanner(System.in); 
		numero_r3=leer.nextInt();

		
		float suma=0;
		suma+=(1/numero_r1 + 1/numero_r2 + 1/numero_r3);
		
		float rt=0;
		rt=(1/suma);
		System.out.println("La resistencia total es: " + rt);
		
		
		
		
		
		
	}

}
