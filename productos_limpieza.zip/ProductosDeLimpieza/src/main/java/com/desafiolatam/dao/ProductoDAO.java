package com.desafiolatam.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.desafiolatam.dto.ProductoDTO;

public class ProductoDAO {

	public int insertarProducto(ProductoDTO dto) throws SQLException, ClassNotFoundException {

		int max=0;

		try {


			String consultaProximoId = "select max(id_producto)+1 from producto";

			String insertarProducto = "insert into producto (nombre_producto, precio_producto, descripcion_producto, id_categoria)" 
					+ "values("
					+ "'" + dto.getNombre_producto() + "'" + ","
					+ dto.getPrecio_producto() + " ,"
					+ "'" + dto.getDescripcion_producto() + "'" + ","
					+ dto.getId_categoria() + ")";

			Class.forName("org.postgresql.Driver");
			Connection conexion = null;

			conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/productos_limpieza","postgres","admin");

			PreparedStatement stmt1 = conexion.prepareStatement(consultaProximoId);
			PreparedStatement stmt2 = conexion.prepareStatement(insertarProducto);

			stmt1.executeQuery();
			stmt2.executeUpdate();

		}catch(Exception ex) {
			ex.printStackTrace();

		}
		return max;
	}

	public List<ProductoDTO> obtieneProductos() throws SQLException, ClassNotFoundException{
		List<ProductoDTO> productos = new ArrayList<ProductoDTO>();


		try {
			String consultaSQL = "select id_producto, nombre_producto, precio_producto, descripcion_producto, id_categoria from producto";

			Class.forName("org.postgresql.Driver");
			Connection conexion = null;
			String url = "jdbc:postgresql://127.0.0.1:5432/productos_limpieza";
			conexion = DriverManager.getConnection(url, "postgres", "admin");

			PreparedStatement stmt = conexion.prepareStatement(consultaSQL);

			ResultSet resultado = stmt.executeQuery();
			while(resultado.next()) {
				ProductoDTO producto = new ProductoDTO();
				producto.setId_producto(resultado.getInt("id_producto"));
				producto.setNombre_producto(resultado.getString("nombre_producto"));
				producto.setPrecio_producto(resultado.getInt("precio_producto"));
				producto.setDescripcion_producto(resultado.getString("descripcion_producto"));
				producto.setId_categoria(resultado.getInt("id_categoria"));
				productos.add(producto);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return productos;

	}



	public int eliminaProductos(Integer idUsuario) throws SQLException, ClassNotFoundException{

		int idU = idUsuario;

		try {

			String eliminarSQL = "delete from producto where id_producto=?";
			Class.forName("org.postgresql.Driver");

			Connection conexion = null;

			conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/productos_limpieza", "postgres", "admin");

			PreparedStatement stmt = conexion.prepareStatement(eliminarSQL);

			stmt.setInt(1, idU);

			stmt.executeUpdate();

		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return idU;
	}

	public ProductoDTO encuentraProductos(Integer idUsuario) throws SQLException, ClassNotFoundException{

		int idU = idUsuario;

		ProductoDTO producto = new ProductoDTO();

		try {

			String encontrarSQL = "select nombre_producto, precio_producto, descripcion_producto, id_categoria from producto where id_producto=?";

			Class.forName("org.postgresql.Driver");

			Connection conexion = null;

			conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/productos_limpieza","postgres", "admin");

			PreparedStatement stmt = conexion.prepareStatement(encontrarSQL);

			stmt.setInt(1, idU);

			ResultSet resultado = stmt.executeQuery();

			while(resultado.next()) {
				producto.setNombre_producto(resultado.getString("nombre_producto"));
				producto.setPrecio_producto(resultado.getInt("precio_producto"));
				producto.setDescripcion_producto(resultado.getString("descripcion_producto"));
				producto.setId_categoria(resultado.getInt("id_categoria"));	

			}

		}catch(SQLException e) {
			e.printStackTrace();
		}

		return producto;
	}


	public void edicionProducto(ProductoDTO dto, Integer idProducto) throws SQLException, ClassNotFoundException{

		int idU = idProducto;

		try {

			String actualizarSQL = "update producto set nombre_producto=?, precio_producto=?, descripcion_producto=?, id_categoria=? where id_producto=?";

			Class.forName("org.postgresql.Driver");

			Connection conexion = null;

			conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/productos_limpieza", "postgres", "admin");

			PreparedStatement stmt = conexion.prepareStatement(actualizarSQL);

			stmt.setString(1, dto.getNombre_producto());
			stmt.setInt(2, dto.getPrecio_producto());
			stmt.setString(3, dto.getDescripcion_producto());
			stmt.setInt(4, dto.getId_categoria());
			stmt.setInt(5, idU);

			stmt.executeUpdate();

		}catch(Exception ex) {
			ex.printStackTrace();
		}

	}

}



