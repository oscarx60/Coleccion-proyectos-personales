package Patrones;
import java.util.Scanner;
public class Patr�n1 {
	public static void main(String[] args) {
		System.out.println("Ingrese numero para cantidad de astericos y puntos");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		for (int i=0; i<n; i++) { 
			if((i%2)==0) {
				System.out.print("*");}
			else {System.out.print(".");}



		}
		System.out.printf("\n");
	}
}