package cl.adl.sistemanoticias.reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class SistemaNoticiasFileReader {
	
	public ArrayList<String> leerArchivo(String archivo) throws IOException {
		
		ArrayList<String> datosDeArchivo = new ArrayList<String>();
		
		try {
			String file = "src/main/resources/" + archivo;
			
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String lineaActual = reader.readLine();
			
			
			while(lineaActual != null) {
				datosDeArchivo.add(lineaActual);
				lineaActual = reader.readLine();
			}
			
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return datosDeArchivo;
	}

}
