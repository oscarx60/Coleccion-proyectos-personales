package ReciclaJeans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class ArchivoServicio {

	public void cargarDatos(String ruta, List<Producto> listaProductos)throws IOException{

		File creararchivo = new File(ruta);

		try {
			if(!creararchivo.isFile()) {

				System.out.println("El archivo que esta intentando abrir no existe o no se encuentra en la ruta especificada");
			}

			else {

				FileReader lectorArchivo = new FileReader(creararchivo);
				BufferedReader lectorB = new BufferedReader(lectorArchivo);

				String datosArchivo = lectorB.readLine();
				while (datosArchivo!=null) {
					Producto producto = new Producto(); // Creamos un nuevo producto que sera reemplazado con cada producto
					String[]data = datosArchivo.split(",", 7); // Crea un array estatico que separa cada dato cuando se topa con una coma

					producto.setArticulo(data[0]); // Accedo a cada espacio del array data e ingreso los datos de CSV a mi nuevo producto
					producto.setPrecio(data[1]);
					producto.setColor(data[6]);
					producto.setDescripcion(data[2]);
					producto.setMarca(data[5]);
					producto.setCodigo(data[3]);
					producto.setTalla(data[4]);

					listaProductos.add(producto); // Producto una vez armado es entregado a la lista
					datosArchivo = lectorB.readLine(); // Comienzo a leer la siguiente linea y los datos son nuevamente inicializados al inicio de mi while
				}
				lectorB.close();
				System.out.println("Los datos han sido agregados a la lista correctamente");
				Utilidad.espera();
				System.out.println("Favor confirmar nuevos datos en Listar Productos o Exportar datos");
			}
		}catch (IOException e) {
			System.out.println("Error: Se ha generado el siguiente error al intentar leer el archivo" + e.getMessage());
		}
	}

}
