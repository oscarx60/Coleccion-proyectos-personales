/**
 * 
 */
package Automotora;

/**
 * @author Oscar Alvarez C.
 *
 */
public class Automotora {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Bus volvo = new Bus("Azul", "LCRP21", 30);
		Vehiculo Swift = new Vehiculo("Azul met�lico", "YTDG24");
		Taxi miTaxi = new Taxi(2000);
		MiniBus miMiniBus = new MiniBus("Verde", "ABCD", 20, "Escolar");
		Cliente Rodrigo = new Cliente("17120747-9", "Rodrigo", 30, 35);
		Persona identificacion = new Persona("17567389-k", "David", 32);
		Vendedor oscar = new Vendedor("19405856-k", "Benjamin", 25, "Las Rosas 238");
		Tienda derco = new Tienda(oscar, Swift, 44);
		LibroVenta libro2021 = new LibroVenta("VentaOctubre", "05102021");
		
		libro2021.guardarVenta(Rodrigo, Swift);
		

		miTaxi.pagarPasaje();

		System.out.println(volvo.asientosDisponibles());
		miMiniBus.imprimeBus();


		System.out.println(derco.existeStock());



	}

}
