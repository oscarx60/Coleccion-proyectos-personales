package SoloPares;

import java.util.Scanner;

public class SoloPares {

	public static void main(String[] args) {
		
		System.out.println("Ingrese la cantidad de n�meros pares necesarios:");
		Scanner sc= new Scanner(System.in);
		int numero= sc.nextInt();
		int i=0;
		
		while (i< numero); 
				
		if((i%2)==0);
		
		System.out.println("n�mero par: " + i);
	

}
