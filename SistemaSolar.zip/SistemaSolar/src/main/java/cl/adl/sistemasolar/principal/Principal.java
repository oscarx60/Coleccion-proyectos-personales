package cl.adl.sistemasolar.principal;

import java.util.ArrayList;

import cl.adl.sistemasolar.Planeta;
import cl.adl.sistemasolar.interfaz.impl.ILunaImpl;
import cl.adl.sistemasolar.interfaz.impl.IPlanetaImpl;

public class Principal {

	public static void main(String[] args) {
		
		// Mercurio

		IPlanetaImpl planetaMercurio = new IPlanetaImpl();
		Planeta mercurio = planetaMercurio.construirPlaneta("Mercurio", "2439km", "58 millones de kilometros", "", null,
				null);
		
		// Venus

		IPlanetaImpl planetaVenus = new IPlanetaImpl();
		Planeta venus = planetaVenus.construirPlaneta("Venus", "6051km", "108 millones de kilometros", "", null, null);

		// Tierra
		
		ILunaImpl lunaTierra = new ILunaImpl();
		IPlanetaImpl planetaTierra = new IPlanetaImpl();
		Planeta tierra = planetaTierra.construirPlaneta("Tierra", "6371km", "149 millones de kilometros", "Luna: 384 mil km", lunaTierra.construirLuna("Luna", "3474km", "29 dias"), null);
		
		// Marte

		ILunaImpl lunaMarte = new ILunaImpl();
		IPlanetaImpl planetaMarte = new IPlanetaImpl();
		Planeta marte = planetaMarte.construirPlaneta("Marte", "3389km", "249 millones de kilometros",
				"Fobos: 9377km, Deimos: 23460km", lunaMarte.construirLuna("Fobos", "22533km", "7 horas"),
				lunaMarte.construirLuna("Deimos", "12.4km", "1 dia"));
		
		// Jupiter

		ILunaImpl lunaJupiter = new ILunaImpl();
		IPlanetaImpl planetaJupiter = new IPlanetaImpl();
		Planeta jupiter = planetaJupiter.construirPlaneta("Jupiter", "69911km", "750 millones de kilometros",
				"Io: 421 mil km, Europa: 670 mil km", lunaJupiter.construirLuna("Io", "3643km", "1 dia"),
				lunaJupiter.construirLuna("Europa", "3122km", "3 dias"));
		
		// Saturno

		ILunaImpl lunaSaturno = new ILunaImpl();
		IPlanetaImpl planetaSaturno = new IPlanetaImpl();
		Planeta saturno = planetaSaturno.construirPlaneta("Saturno", "58232km", "1418 millones de kilometros",
				"Atlas: 132 mil km, Prometeo: 139 mil km", lunaSaturno.construirLuna("Atlas", "32km", "0.60 dias"),
				lunaSaturno.construirLuna("Prometeo", "86km", "0.61 dias"));
		
		// Urano

		ILunaImpl lunaUrano = new ILunaImpl();
		IPlanetaImpl planetaUrano = new IPlanetaImpl();
		Planeta urano = planetaUrano.construirPlaneta("Urano", "25362km", "3000 millones de kilometros",
				"Cordelia: 49 mil km, Ofelia: 53 mil km", lunaUrano.construirLuna("Cordelia", "26km", "0.33 dias"),
				lunaUrano.construirLuna("Ofelia", "32km", "0.37 dias"));
		
		// Neptuno

		ILunaImpl lunaNeptuno = new ILunaImpl();
		IPlanetaImpl planetaNeptuno = new IPlanetaImpl();
		Planeta neptuno = planetaNeptuno.construirPlaneta("Neptuno", "24622km", "4500 millones de kilometros",
				"Nayade: 48 mil km, Talasa: 50 mil km", lunaNeptuno.construirLuna("Nayade", "58km", "0.29 dias"),
				lunaNeptuno.construirLuna("Talasa", "80km", "0.31 dias"));
		
		// Lista de planetas

		ArrayList<Planeta> listaDePlanetas = new ArrayList<Planeta>();
		listaDePlanetas.add(mercurio);
		listaDePlanetas.add(venus);
		listaDePlanetas.add(tierra);
		listaDePlanetas.add(marte);
		listaDePlanetas.add(jupiter);
		listaDePlanetas.add(saturno);
		listaDePlanetas.add(urano);
		listaDePlanetas.add(neptuno);

		for (Planeta planeta : listaDePlanetas) {
			System.out.println(planeta);
		}

	}

}
