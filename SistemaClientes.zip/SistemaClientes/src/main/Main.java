/**
 * 
 */
package main;

import vista.Menu;

/**
 * @author Oscar Alvarez
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Menu menu = new Menu();

		menu.iniciarMenu();

	}
}
